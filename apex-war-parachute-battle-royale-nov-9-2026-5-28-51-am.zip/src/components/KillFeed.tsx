/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { KillFeedItem } from '../game/types';

interface KillFeedProps {
  items: KillFeedItem[];
  isArabic: boolean;
}

export const KillFeed: React.FC<KillFeedProps> = ({ items, isArabic }) => {
  return (
    <div className="flex flex-col gap-1.5 pointer-events-none items-end max-w-sm">
      {items.slice(-4).map((item) => (
        <div
          key={item.id}
          className={`flex items-center gap-2 px-3 py-1 rounded text-xs font-semibold shadow-md border animate-fade-in ${
            item.isPlayerInvolved
              ? 'bg-amber-950/90 border-amber-500/80 text-amber-200'
              : 'bg-slate-900/80 border-slate-700/60 text-slate-300'
          }`}
          dir={isArabic ? 'rtl' : 'ltr'}
        >
          <span className="font-bold text-white">{item.killerName}</span>
          {item.isHeadshot ? (
            <span className="text-red-500 font-extrabold text-sm" title="Headshot">
              🎯
            </span>
          ) : (
            <span className="text-amber-400">⚔️</span>
          )}
          <span className="text-xs px-1.5 py-0.5 rounded bg-black/40 text-slate-400 font-mono">
            {item.weaponName.split(' ')[0]}
          </span>
          <span className="text-red-300 font-bold">{item.victimName}</span>
        </div>
      ))}
    </div>
  );
};
