/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect, useCallback } from 'react';

interface TouchControlsProps {
  onMove: (dir: { x: number; y: number }) => void;
  onShootStart: () => void;
  onShootEnd: () => void;
  onJump: () => void;
  onSprint: (sprinting: boolean) => void;
  onReload: () => void;
  onGlooWall: () => void;
  onMedkit: () => void;
  onLookDrag: (dx: number, dy: number) => void;
  glooCount: number;
  medkitCount: number;
  isParachuting: boolean;
  isArabic: boolean;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  onMove,
  onShootStart,
  onShootEnd,
  onJump,
  onSprint,
  onReload,
  onGlooWall,
  onMedkit,
  onLookDrag,
  glooCount,
  medkitCount,
  isParachuting,
  isArabic
}) => {
  const joystickRef = useRef<HTMLDivElement | null>(null);
  const [knobPos, setKnobPos] = useState({ x: 0, y: 0 });
  const [touchId, setTouchId] = useState<number | null>(null);
  const lastLookPos = useRef<{ x: number; y: number } | null>(null);

  // Joystick touch handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    if (touchId !== null) return;
    const touch = e.changedTouches[0];
    setTouchId(touch.identifier);
    updateKnob(touch.clientX, touch.clientY);
  };

  const handleTouchMove = useCallback((e: TouchEvent) => {
    if (touchId === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === touchId) {
        updateKnob(touch.clientX, touch.clientY);
        break;
      }
    }
  }, [touchId]);

  const handleTouchEnd = useCallback((e: TouchEvent) => {
    if (touchId === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === touchId) {
        setTouchId(null);
        setKnobPos({ x: 0, y: 0 });
        onMove({ x: 0, y: 0 });
        break;
      }
    }
  }, [touchId, onMove]);

  const updateKnob = (clientX: number, clientY: number) => {
    if (!joystickRef.current) return;
    const rect = joystickRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    let dx = clientX - centerX;
    let dy = clientY - centerY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const maxRadius = 45;

    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }

    setKnobPos({ x: dx, y: dy });
    onMove({ x: dx / maxRadius, y: dy / maxRadius });
  };

  useEffect(() => {
    window.addEventListener('touchmove', handleTouchMove);
    window.addEventListener('touchend', handleTouchEnd);
    return () => {
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [handleTouchMove, handleTouchEnd]);

  // Aim look swipe area on right side of screen
  const handleLookStart = (e: React.TouchEvent) => {
    const touch = e.changedTouches[0];
    lastLookPos.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleLookMove = (e: React.TouchEvent) => {
    if (!lastLookPos.current) return;
    const touch = e.changedTouches[0];
    const dx = touch.clientX - lastLookPos.current.x;
    const dy = touch.clientY - lastLookPos.current.y;
    lastLookPos.current = { x: touch.clientX, y: touch.clientY };
    onLookDrag(dx, dy);
  };

  const handleLookEnd = () => {
    lastLookPos.current = null;
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-20">
      {/* Right side touch-look swipe pad */}
      <div
        className="absolute top-16 right-0 bottom-32 w-1/2 pointer-events-auto opacity-0"
        onTouchStart={handleLookStart}
        onTouchMove={handleLookMove}
        onTouchEnd={handleLookEnd}
      />

      {/* Movement Virtual Joystick (Bottom Left) */}
      <div className="absolute bottom-6 left-6 pointer-events-auto">
        <div
          ref={joystickRef}
          onTouchStart={handleTouchStart}
          className="relative w-28 h-28 rounded-full border-2 border-white/30 bg-black/40 flex items-center justify-center touch-none shadow-2xl"
        >
          <div
            className="w-12 h-12 rounded-full bg-amber-500/80 border-2 border-white shadow-lg pointer-events-none transition-transform duration-75"
            style={{ transform: `translate(${knobPos.x}px, ${knobPos.y}px)` }}
          />
        </div>
      </div>

      {/* Action Combat Buttons (Bottom Right) */}
      <div className="absolute bottom-6 right-6 flex flex-col items-end gap-3 pointer-events-auto">
        {/* Tactical items row: Gloo Wall & Medkit */}
        <div className="flex items-center gap-3">
          <button
            onClick={onMedkit}
            className="relative w-12 h-12 rounded-full bg-emerald-600 border-2 border-emerald-300 text-white font-bold flex items-center justify-center shadow-lg active:scale-95"
            title="Medkit (H)"
          >
            <span>➕</span>
            <span className="absolute -top-1 -right-1 bg-black text-emerald-300 text-xs px-1.5 py-0.2 rounded-full border border-emerald-400">
              {medkitCount}
            </span>
          </button>

          <button
            onClick={onGlooWall}
            className="relative w-12 h-12 rounded-full bg-cyan-600 border-2 border-cyan-300 text-white font-bold flex items-center justify-center shadow-lg active:scale-95"
            title="Gloo Wall (G)"
          >
            <span>🛡️</span>
            <span className="absolute -top-1 -right-1 bg-black text-cyan-300 text-xs px-1.5 py-0.2 rounded-full border border-cyan-400">
              {glooCount}
            </span>
          </button>

          <button
            onClick={onReload}
            className="w-11 h-11 rounded-full bg-slate-800/90 border border-slate-500 text-slate-200 text-sm font-bold flex items-center justify-center shadow-lg active:scale-95"
            title="Reload (R)"
          >
            🔄
          </button>
        </div>

        {/* Jump & Shoot triggers */}
        <div className="flex items-center gap-4">
          <button
            onClick={onJump}
            className="w-14 h-14 rounded-full bg-blue-600/90 border-2 border-blue-300 text-white font-bold flex items-center justify-center shadow-xl active:scale-95"
            title="Jump (Space)"
          >
            <span className="text-xl">⬆️</span>
          </button>

          {!isParachuting && (
            <button
              onTouchStart={onShootStart}
              onTouchEnd={onShootEnd}
              onMouseDown={onShootStart}
              onMouseUp={onShootEnd}
              className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-600 to-red-600 border-4 border-amber-300 text-white font-extrabold flex items-center justify-center shadow-2xl active:scale-90"
              title="Fire (LMB)"
            >
              <div className="flex flex-col items-center">
                <span className="text-2xl">🎯</span>
                <span className="text-[10px] tracking-wider uppercase font-black">
                  {isArabic ? 'إطلاق' : 'FIRE'}
                </span>
              </div>
            </button>
          )}

          {isParachuting && (
            <button
              onTouchStart={() => onSprint(true)}
              onTouchEnd={() => onSprint(false)}
              className="w-20 h-20 rounded-full bg-gradient-to-tr from-orange-600 to-red-600 border-4 border-orange-300 text-white font-extrabold flex items-center justify-center shadow-2xl active:scale-90"
            >
              <div className="flex flex-col items-center">
                <span className="text-2xl">⚡</span>
                <span className="text-[10px] tracking-wider uppercase font-black">
                  {isArabic ? 'هبوط سريع' : 'DIVE'}
                </span>
              </div>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
