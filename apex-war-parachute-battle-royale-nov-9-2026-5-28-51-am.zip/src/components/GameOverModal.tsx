/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { MatchStats } from '../game/types';

interface GameOverModalProps {
  victory: boolean;
  stats: MatchStats;
  onRestart: () => void;
  isArabic: boolean;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  victory,
  stats,
  onRestart,
  isArabic
}) => {
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in select-none">
      <div className="w-full max-w-md p-6 rounded-2xl bg-slate-900 border-2 border-amber-500/70 shadow-[0_0_50px_rgba(245,158,11,0.35)] flex flex-col items-center text-center">
        {/* Victory "BOOYAH!" or Defeat Banner */}
        {victory ? (
          <div className="mb-4">
            <div className="text-6xl mb-2 drop-shadow-lg">🏆</div>
            <h2 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 tracking-wider">
              {isArabic ? 'BOOYAH! النصر' : 'BOOYAH!'}
            </h2>
            <p className="text-sm font-bold text-amber-300 tracking-widest uppercase mt-1">
              {isArabic ? 'أنت بطل المعركة والناجي الأخير!' : 'CHAMPION OF THE BATTLEGROUND!'}
            </p>
          </div>
        ) : (
          <div className="mb-4">
            <div className="text-5xl mb-2">💀</div>
            <h2 className="text-4xl font-black text-red-500 tracking-wider">
              {isArabic ? 'تمت تصفيتك' : 'ELIMINATED'}
            </h2>
            <p className="text-sm font-bold text-slate-400 tracking-widest uppercase mt-1">
              {isArabic ? `المركز #${stats.rank} من ${stats.totalCombatants}` : `Rank #${stats.rank} of ${stats.totalCombatants}`}
            </p>
          </div>
        )}

        {/* Stats Grid */}
        <div className="w-full grid grid-cols-2 gap-3 my-5 text-left" dir={isArabic ? 'rtl' : 'ltr'}>
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs text-slate-400 uppercase font-bold block">
              {isArabic ? 'القتلى' : 'Total Kills'}
            </span>
            <span className="text-2xl font-black text-amber-400 tabular-nums">
              {stats.kills}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs text-slate-400 uppercase font-bold block">
              {isArabic ? 'إصابات الرأس' : 'Headshots'}
            </span>
            <span className="text-2xl font-black text-red-400 tabular-nums">
              {stats.headshots}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs text-slate-400 uppercase font-bold block">
              {isArabic ? 'الضرر المُلحق' : 'Damage Dealt'}
            </span>
            <span className="text-2xl font-black text-blue-400 tabular-nums">
              {stats.damageDealt}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs text-slate-400 uppercase font-bold block">
              {isArabic ? 'وقت البقاء' : 'Survival Time'}
            </span>
            <span className="text-2xl font-black text-emerald-400 tabular-nums font-mono">
              {formatTime(stats.survivalTimeSec)}
            </span>
          </div>
        </div>

        {/* Play Again Button */}
        <button
          onClick={onRestart}
          className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white font-extrabold text-base tracking-wider uppercase shadow-xl active:scale-95 transition-all cursor-pointer border border-amber-300"
        >
          {isArabic ? 'العب معركة جديدة 🪂' : 'PLAY NEW MATCH 🪂'}
        </button>
      </div>
    </div>
  );
};
