/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { SafeZone } from '../game/types';
import { ISLAND_RADIUS } from '../game/world';

interface MinimapProps {
  playerPos: THREE.Vector3;
  playerYaw: number;
  enemies: { pos: THREE.Vector3; firing: boolean }[];
  safeZone: SafeZone | null;
}

export const Minimap: React.FC<MinimapProps> = ({ playerPos, playerYaw, enemies, safeZone }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = 150;
    const center = size / 2;
    const scale = (size * 0.44) / (ISLAND_RADIUS * 1.05);

    ctx.clearRect(0, 0, size, size);

    // Circular radar frame clipping
    ctx.save();
    ctx.beginPath();
    ctx.arc(center, center, center - 4, 0, Math.PI * 2);
    ctx.clip();

    // Map background: dark military topographical grid
    ctx.fillStyle = '#064e3b'; // dark forest green
    ctx.fillRect(0, 0, size, size);

    // Ocean water ring
    ctx.strokeStyle = '#0284c7';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(center, center, ISLAND_RADIUS * scale, 0, Math.PI * 2);
    ctx.stroke();

    // Radar coordinate grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(center, 0); ctx.lineTo(center, size);
    ctx.moveTo(0, center); ctx.lineTo(size, center);
    ctx.stroke();

    // Draw Safe Zone (Blue Storm)
    if (safeZone) {
      // Current blue storm circle
      ctx.strokeStyle = 'rgba(14, 165, 233, 0.85)';
      ctx.fillStyle = 'rgba(14, 165, 233, 0.12)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(center + safeZone.center.x * scale, center + safeZone.center.y * scale, safeZone.currentRadius * scale, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Target safe white circle
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.setLineDash([4, 4]);
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(center + safeZone.targetCenter.x * scale, center + safeZone.targetCenter.y * scale, safeZone.targetRadius * scale, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Draw enemies firing or in proximity
    enemies.forEach(e => {
      const ex = center + e.pos.x * scale;
      const ey = center + e.pos.z * scale;

      ctx.beginPath();
      ctx.arc(ex, ey, e.firing ? 4.5 : 2.5, 0, Math.PI * 2);
      ctx.fillStyle = e.firing ? '#ef4444' : '#f97316';
      ctx.fill();

      if (e.firing) {
        ctx.strokeStyle = '#f87171';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
    });

    // Draw Player Indicator (arrow oriented with yaw)
    const px = center + playerPos.x * scale;
    const py = center + playerPos.z * scale;

    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(-playerYaw);

    // Player cone arrow
    ctx.fillStyle = '#facc15'; // golden yellow
    ctx.beginPath();
    ctx.moveTo(0, -6);
    ctx.lineTo(4, 5);
    ctx.lineTo(0, 3);
    ctx.lineTo(-4, 5);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();

    ctx.restore();

    // Outer border ring
    ctx.strokeStyle = '#eab308';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(center, center, center - 3, 0, Math.PI * 2);
    ctx.stroke();

    // Compass cardinal markers
    ctx.fillStyle = '#facc15';
    ctx.font = '10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('N', center, 14);
  }, [playerPos, playerYaw, enemies, safeZone]);

  return (
    <div className="relative p-1 rounded-full bg-slate-950/80 border border-amber-500/40 shadow-xl backdrop-blur-none pointer-events-auto">
      <canvas ref={canvasRef} width={150} height={150} className="rounded-full" />
    </div>
  );
};
