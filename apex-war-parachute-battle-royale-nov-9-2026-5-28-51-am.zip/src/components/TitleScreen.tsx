/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';

interface TitleScreenProps {
  onStart: () => void;
  isArabic: boolean;
  onToggleLang: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStart,
  isArabic,
  onToggleLang,
  isMuted,
  onToggleMute
}) => {
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.code === 'Enter' || e.code === 'Space') {
        onStart();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onStart]);

  return (
    <div className="absolute inset-0 flex flex-col justify-between p-8 z-30 select-none bg-gradient-to-b from-black/60 via-transparent to-black/80 pointer-events-none">
      {/* Top bar with audio & language toggles */}
      <div className="flex justify-between items-center w-full pointer-events-auto">
        <div className="flex items-center gap-3">
          <span className="px-3 py-1 rounded bg-amber-500/20 border border-amber-500/40 text-amber-400 font-mono text-xs font-bold uppercase tracking-widest">
            {isArabic ? 'باتل رويال ٣دي' : 'BATTLE ROYALE 3D'}
          </span>
          <span className="px-2.5 py-1 rounded bg-red-950/60 border border-red-500/30 text-red-400 text-xs font-bold">
            FREE FIRE ENGINE v2.4
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onToggleLang}
            className="px-3 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-bold transition-colors cursor-pointer"
          >
            {isArabic ? 'English' : 'عربي'}
          </button>
          <button
            onClick={onToggleMute}
            className="p-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-bold transition-colors cursor-pointer"
            title="Toggle Sound"
          >
            {isMuted ? '🔇' : '🔊'}
          </button>
        </div>
      </div>

      {/* Hero Title Lockup with Bespoke SVG Graphic */}
      <div className="flex flex-col items-center justify-center text-center my-auto pointer-events-auto max-w-2xl mx-auto">
        {/* Parachute & Wings Graphic Icon */}
        <div className="w-24 h-24 mb-4 drop-shadow-[0_0_25px_rgba(245,158,11,0.5)]">
          <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
            {/* Parachute canopy arc */}
            <path
              d="M10 48C10 24 28 8 50 8C72 8 90 24 90 48C90 48 76 43 64 45C52 47 50 49 50 49C50 49 48 47 36 45C24 43 10 48 10 48Z"
              fill="url(#canopyGrad)"
              stroke="#F59E0B"
              strokeWidth="2.5"
            />
            {/* Parachute rib lines */}
            <path d="M50 8V49M28 17L50 49M72 17L50 49M12 48L50 78M88 48L50 78M36 45L50 78M64 45L50 78" stroke="#FDE68A" strokeWidth="1.2" strokeOpacity="0.8" />
            {/* Combatant silhouette */}
            <circle cx="50" cy="74" r="3.5" fill="#EF4444" />
            <rect x="47.5" y="78" width="5" height="10" rx="1.5" fill="#EF4444" />
            {/* Crossed swords accent */}
            <path d="M30 85L70 85M38 78L62 92M62 78L38 92" stroke="#EAB308" strokeWidth="2" strokeLinecap="round" />
            <defs>
              <linearGradient id="canopyGrad" x1="10" y1="8" x2="90" y2="48" gradientUnits="userSpaceOnUse">
                <stop stopColor="#DC2626" />
                <stop offset="0.5" stopColor="#EA580C" />
                <stop offset="1" stopColor="#F59E0B" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* Title Lockup */}
        <h1 className="text-4xl md:text-6xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 drop-shadow-[0_4px_16px_rgba(0,0,0,0.9)]">
          {isArabic ? 'حرب البقاء: مظلة الموت' : 'APEX WAR: PARACHUTE BATTLE'}
        </h1>
        <p className="text-sm md:text-base font-semibold text-amber-200/90 mt-2 tracking-wide uppercase">
          {isArabic
            ? 'اقفز بالمظلة في قلب المعركة • اهبط واقضِ على الجميع • حقق النصر BOOYAH!'
            : 'SKYDIVING AIR DROP • LOOT & SHOOT • SURVIVE TO GET BOOYAH!'}
        </p>

        {/* Start Game CTA Button */}
        <button
          onClick={onStart}
          className="mt-8 px-10 py-4 rounded-xl bg-gradient-to-r from-amber-500 via-orange-600 to-red-600 hover:from-amber-400 hover:to-red-500 text-white font-black text-lg md:text-xl tracking-wider shadow-[0_0_35px_rgba(249,115,22,0.6)] hover:shadow-[0_0_45px_rgba(249,115,22,0.85)] active:scale-95 transition-all cursor-pointer border border-amber-300"
        >
          {isArabic ? '🪂 اقفز الآن (ENTER)' : '🪂 DEPLOY PARACHUTE (ENTER)'}
        </button>
      </div>

      {/* Flat Control Hints Bar at Bottom */}
      <div className="w-full flex justify-center pointer-events-auto">
        <div className="px-5 py-2 rounded-full bg-slate-950/80 border border-slate-700/60 text-slate-300 text-xs font-mono font-medium tracking-wide shadow-lg">
          {isArabic
            ? 'WASD تحرك وتوجيه المظلة · انقر لإطلاق النار · Shift تسريع الهبوط والركض · G جدار الغلو · H علاج · Space قفز'
            : 'WASD Steer Chute & Move · Click Aim & Fire · Shift Fast-Dive & Sprint · G Gloo Wall · H Medkit · Space Jump'}
        </div>
      </div>
    </div>
  );
};
