/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { WeaponType, SafeZone, KillFeedItem } from '../game/types';
import { WEAPON_DEFINITIONS } from '../game/weapons';
import { Minimap } from './Minimap';
import { KillFeed } from './KillFeed';
import * as THREE from 'three';

interface GameHUDProps {
  health: number;
  maxHealth: number;
  armor: number;
  maxArmor: number;
  aliveCount: number;
  kills: number;
  currentWeapon: WeaponType;
  currentAmmo: number;
  reserveAmmo: number;
  isReloading: boolean;
  glooCount: number;
  medkitCount: number;
  altitude: number;
  speed: number;
  isParachuting: boolean;
  safeZone: SafeZone | null;
  killFeed: KillFeedItem[];
  hitMarkerActive: boolean;
  isHeadshotHit: boolean;
  playerPos: THREE.Vector3;
  playerYaw: number;
  enemies: { pos: THREE.Vector3; firing: boolean }[];
  isArabic: boolean;
  onSwitchWeapon: (idx: number) => void;
  onDeployGloo: () => void;
  onUseMedkit: () => void;
  onReload: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  health,
  maxHealth,
  armor,
  maxArmor,
  aliveCount,
  kills,
  currentWeapon,
  currentAmmo,
  reserveAmmo,
  isReloading,
  glooCount,
  medkitCount,
  altitude,
  speed,
  isParachuting,
  safeZone,
  killFeed,
  hitMarkerActive,
  isHeadshotHit,
  playerPos,
  playerYaw,
  enemies,
  isArabic,
  onSwitchWeapon,
  onDeployGloo,
  onUseMedkit,
  onReload
}) => {
  const [hudCollapsed, setHudCollapsed] = useState(false);

  const wepKeys: WeaponType[] = ['AR', 'SHOTGUN', 'SNIPER', 'KATANA'];

  // Format safe zone timer
  const zoneSeconds = safeZone ? Math.max(0, Math.floor(safeZone.timeUntilNextShrink)) : 0;
  const zoneMin = Math.floor(zoneSeconds / 60);
  const zoneSec = zoneSeconds % 60;
  const zoneTimerStr = `${zoneMin}:${zoneSec < 10 ? '0' : ''}${zoneSec}`;

  return (
    <div className="absolute inset-0 pointer-events-none select-none flex flex-col justify-between p-4 z-20">
      {/* Top Header Status Cluster */}
      <div className="flex justify-between items-start w-full gap-4">
        {/* Left: Alive & Kills Status */}
        <div className="flex flex-col gap-2 pointer-events-auto">
          <div className="flex items-center gap-3 px-4 py-2 rounded-xl bg-slate-950/85 border border-amber-500/40 shadow-xl">
            {/* Alive Counter */}
            <div className="flex items-center gap-2">
              <span className="text-amber-400 text-lg">👤</span>
              <div className="flex flex-col">
                <span className="text-[10px] text-slate-400 uppercase font-black tracking-wider">
                  {isArabic ? 'الأحياء' : 'ALIVE'}
                </span>
                <span className="text-xl font-black text-white tabular-nums">
                  {aliveCount}
                </span>
              </div>
            </div>

            <div className="h-7 w-px bg-slate-800" />

            {/* Kills Counter */}
            <div className="flex items-center gap-2">
              <span className="text-red-500 text-lg">☠️</span>
              <div className="flex flex-col">
                <span className="text-[10px] text-slate-400 uppercase font-black tracking-wider">
                  {isArabic ? 'القتلى' : 'KILLS'}
                </span>
                <span className="text-xl font-black text-amber-400 tabular-nums">
                  {kills}
                </span>
              </div>
            </div>
          </div>

          {/* Safe Zone Alert Banner */}
          {safeZone && (
            <div className="px-3 py-1.5 rounded-lg bg-sky-950/80 border border-sky-500/50 flex items-center gap-2 shadow-lg">
              <span className="text-sky-400 text-xs font-mono font-bold">
                {safeZone.isShrinking
                  ? (isArabic ? '⚠️ العاصفة تتقلص الآن!' : '⚠️ STORM SHRINKING!')
                  : (isArabic ? `⚡ تقلص المنطقة بعد: ${zoneTimerStr}` : `⚡ ZONE SHRINKS IN: ${zoneTimerStr}`)}
              </span>
            </div>
          )}
        </div>

        {/* Center: Parachute Descent Readout (When in air) */}
        {isParachuting && (
          <div className="flex flex-col items-center bg-black/70 border border-orange-500/60 px-6 py-2.5 rounded-2xl shadow-[0_0_25px_rgba(249,115,22,0.4)] animate-bounce-short">
            <span className="text-xs font-black text-orange-400 uppercase tracking-widest flex items-center gap-1.5">
              <span>🪂</span>
              {isArabic ? 'الهبوط بالمظلة نشط' : 'PARACHUTE GLIDE ACTIVE'}
            </span>
            <div className="flex items-center gap-5 mt-1 font-mono">
              <div className="text-center">
                <span className="text-[10px] text-slate-400 uppercase block">
                  {isArabic ? 'الارتفاع' : 'ALTITUDE'}
                </span>
                <span className="text-lg font-black text-white tabular-nums">
                  {Math.max(0, Math.round(altitude))}m
                </span>
              </div>
              <div className="h-6 w-px bg-slate-700" />
              <div className="text-center">
                <span className="text-[10px] text-slate-400 uppercase block">
                  {isArabic ? 'السرعة' : 'SPEED'}
                </span>
                <span className="text-lg font-black text-amber-300 tabular-nums">
                  {Math.round(speed * 3.6)} km/h
                </span>
              </div>
            </div>
            <span className="text-[10px] text-slate-300 mt-1 font-semibold">
              {isArabic ? 'WASD لتوجيه المظلة • Shift للغوص السريع' : 'WASD to steer • Shift to dive fast'}
            </span>
          </div>
        )}

        {/* Right: Tactical Radar Minimap & KillFeed */}
        <div className="flex flex-col items-end gap-3 pointer-events-auto">
          <Minimap
            playerPos={playerPos}
            playerYaw={playerYaw}
            enemies={enemies}
            safeZone={safeZone}
          />
          <KillFeed items={killFeed} isArabic={isArabic} />
        </div>
      </div>

      {/* Center Screen: Tactical Crosshair & Hit Markers */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {/* Reticle Crosshair */}
        <div className="relative w-8 h-8 flex items-center justify-center">
          <div className="w-1.5 h-1.5 rounded-full bg-amber-400 shadow-[0_0_8px_#f59e0b]" />
          <div className="absolute w-4 h-0.5 bg-white/70 -left-3" />
          <div className="absolute w-4 h-0.5 bg-white/70 -right-3" />
          <div className="absolute w-0.5 h-4 bg-white/70 -top-3" />
          <div className="absolute w-0.5 h-4 bg-white/70 -bottom-3" />

          {/* Hitmarker Tick (Flashes when bullet lands) */}
          {hitMarkerActive && (
            <div className="absolute inset-0 flex items-center justify-center animate-ping">
              <span className={`text-2xl font-black ${isHeadshotHit ? 'text-red-500 scale-125' : 'text-amber-400'}`}>
                ✕
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Unified Bottom Control Dock (Consolidated, Zero Center-Viewport Occlusion) */}
      <div className="flex flex-col items-center pointer-events-auto w-full max-w-4xl mx-auto">
        {/* Collapsible toggle */}
        <button
          onClick={() => setHudCollapsed(!hudCollapsed)}
          className="px-3 py-1 mb-1 rounded-t-lg bg-slate-900/85 hover:bg-slate-800 border-t border-x border-slate-700 text-slate-400 text-xs font-semibold cursor-pointer shadow-md"
        >
          {hudCollapsed
            ? (isArabic ? '▴ إظهار لوحة التحكم (H)' : '▴ Show HUD Dock')
            : (isArabic ? '▾ إخفاء لوحة التحكم (H)' : '▾ Hide HUD Dock')}
        </button>

        {!hudCollapsed && (
          <div className="w-full p-3 rounded-2xl bg-slate-950/90 border border-slate-800 shadow-2xl flex flex-wrap items-center justify-between gap-4">
            {/* Left: Health (HP) & Armor (AP) Bars */}
            <div className="flex flex-col gap-1.5 min-w-[210px]" dir={isArabic ? 'rtl' : 'ltr'}>
              {/* Shield Armor Bar */}
              <div className="flex items-center gap-2">
                <span className="text-cyan-400 text-xs font-bold w-5">🛡️</span>
                <div className="flex-1 h-2.5 rounded-full bg-slate-800 overflow-hidden border border-cyan-900">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-150"
                    style={{ width: `${Math.max(0, (armor / maxArmor) * 100)}%` }}
                  />
                </div>
                <span className="text-xs font-mono font-bold text-cyan-300 w-12 text-right tabular-nums">
                  {Math.round(armor)}/{maxArmor}
                </span>
              </div>

              {/* Health HP Bar */}
              <div className="flex items-center gap-2">
                <span className="text-red-500 text-xs font-bold w-5">❤️</span>
                <div className="flex-1 h-3.5 rounded-full bg-slate-800 overflow-hidden border border-red-950">
                  <div
                    className="h-full bg-gradient-to-r from-red-600 via-orange-500 to-amber-500 transition-all duration-150"
                    style={{ width: `${Math.max(0, (health / maxHealth) * 100)}%` }}
                  />
                </div>
                <span className="text-xs font-mono font-extrabold text-white w-12 text-right tabular-nums">
                  {Math.round(health)}/{maxHealth}
                </span>
              </div>
            </div>

            {/* Center: Tactical Utility Items (Gloo Wall + Medkit) */}
            <div className="flex items-center gap-2.5">
              {/* Gloo Wall item */}
              <button
                onClick={onDeployGloo}
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-500/60 text-cyan-200 cursor-pointer transition-all active:scale-95 shadow-md"
                title="Deploy Gloo Wall (G)"
              >
                <span className="text-xl">🛡️</span>
                <div className="flex flex-col text-left">
                  <span className="text-[10px] text-cyan-400 uppercase font-black">
                    {isArabic ? 'جدار غلو [G]' : 'GLOO WALL [G]'}
                  </span>
                  <span className="text-sm font-extrabold text-white tabular-nums">
                    x{glooCount}
                  </span>
                </div>
              </button>

              {/* Medkit item */}
              <button
                onClick={onUseMedkit}
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/60 text-emerald-200 cursor-pointer transition-all active:scale-95 shadow-md"
                title="Use Medkit (H)"
              >
                <span className="text-xl">➕</span>
                <div className="flex flex-col text-left">
                  <span className="text-[10px] text-emerald-400 uppercase font-black">
                    {isArabic ? 'حقيبة علاج [H]' : 'MEDKIT [H]'}
                  </span>
                  <span className="text-sm font-extrabold text-white tabular-nums">
                    x{medkitCount}
                  </span>
                </div>
              </button>
            </div>

            {/* Right: Weapon Slots Selection Dock */}
            <div className="flex items-center gap-2">
              {wepKeys.map((type, idx) => {
                const def = WEAPON_DEFINITIONS[type];
                const isActive = currentWeapon === type;
                return (
                  <button
                    key={type}
                    onClick={() => onSwitchWeapon(idx)}
                    className={`flex flex-col items-center justify-between px-3 py-1.5 rounded-xl border transition-all cursor-pointer ${
                      isActive
                        ? 'bg-amber-500/20 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.4)] scale-105'
                        : 'bg-slate-900/80 border-slate-700/60 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <span className="text-[10px] text-amber-400 font-bold font-mono">
                      {idx + 1}
                    </span>
                    <span className="text-xs font-bold text-white whitespace-nowrap">
                      {type === 'AR' ? 'SCAR-L' : (type === 'SHOTGUN' ? 'M1887' : (type === 'SNIPER' ? 'AWM' : 'KATANA'))}
                    </span>
                    {isActive ? (
                      <span className="text-[11px] font-mono font-black text-amber-300 tabular-nums">
                        {type === 'KATANA'
                          ? '∞'
                          : isReloading
                          ? (isArabic ? 'إعادة تلقيم...' : 'RELOADING...')
                          : `${currentAmmo}/${reserveAmmo}`}
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400 font-mono">
                        {def.ammoType}
                      </span>
                    )}
                  </button>
                );
              })}

              <button
                onClick={onReload}
                className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 cursor-pointer shadow-md active:scale-95"
                title="Reload [R]"
              >
                🔄
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
