/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { WeaponType } from './types';

// Shared reusable materials & palettes to maintain high performance & distinct tactile look
const MAT_SKIN = new THREE.MeshStandardMaterial({ color: 0xdcb898, roughness: 0.8, metalness: 0.05 });
const MAT_TACTICAL_DARK = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5, metalness: 0.2 });
const MAT_HELMET_MILITARY = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.35, metalness: 0.4 });
const MAT_VISOR_GOLD = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.1, metalness: 0.85 });
const MAT_BOOTS = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9, metalness: 0.1 });
const MAT_METAL_GUN = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.3, metalness: 0.85 });
const MAT_GOLD_ACCENT = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.25, metalness: 0.9 });

/**
 * Creates Free Fire style Parachute canopy with suspension lines and harness
 */
export function createParachuteModel(canopyColor: number = 0xff4500): THREE.Group {
  const group = new THREE.Group();
  group.name = 'Parachute';

  // 1. Aerodynamic curved multi-cell canopy
  // Using an elongated sliced half-sphere with flare
  const canopyGeo = new THREE.SphereGeometry(4.2, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.42);
  canopyGeo.scale(1.2, 0.55, 0.9);

  const canopyMat = new THREE.MeshStandardMaterial({
    color: canopyColor,
    roughness: 0.6,
    metalness: 0.1,
    side: THREE.DoubleSide
  });
  const canopyMesh = new THREE.Mesh(canopyGeo, canopyMat);
  canopyMesh.position.y = 5.2;
  canopyMesh.castShadow = true;
  group.add(canopyMesh);

  // 2. Center contrast flame/camo stripe on canopy
  const stripeGeo = new THREE.SphereGeometry(4.22, 16, 6, -Math.PI * 0.15, Math.PI * 0.3, 0, Math.PI * 0.42);
  stripeGeo.scale(1.2, 0.55, 0.9);
  const stripeMat = new THREE.MeshStandardMaterial({
    color: 0xfff000,
    roughness: 0.4,
    metalness: 0.2,
    side: THREE.DoubleSide
  });
  const stripeMesh = new THREE.Mesh(stripeGeo, stripeMat);
  stripeMesh.position.y = 5.2;
  group.add(stripeMesh);

  // 3. Canopy vent hole on top with ring
  const ventGeo = new THREE.TorusGeometry(0.5, 0.08, 8, 16);
  ventGeo.rotateX(Math.PI / 2);
  const ventMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.8 });
  const vent = new THREE.Mesh(ventGeo, ventMat);
  vent.position.y = 7.5;
  group.add(vent);

  // 4. Suspension cords (8 line segments going to central harness connector ring)
  const lineMat = new THREE.LineBasicMaterial({ color: 0xdddddd, transparent: true, opacity: 0.75 });
  const harnessCenter = new THREE.Vector3(0, 1.8, 0);

  const numLines = 8;
  const linePositions: number[] = [];
  for (let i = 0; i < numLines; i++) {
    const angle = (i / numLines) * Math.PI * 2;
    const px = Math.cos(angle) * 3.8 * 1.2;
    const pz = Math.sin(angle) * 3.8 * 0.9;
    const py = 5.2 + Math.cos(Math.PI * 0.42) * 4.2 * 0.55;

    linePositions.push(px, py, pz);
    linePositions.push(harnessCenter.x, harnessCenter.y, harnessCenter.z);
  }

  const linesGeo = new THREE.BufferGeometry();
  linesGeo.setAttribute('position', new THREE.Float32BufferAttribute(linePositions, 3));
  const linesMesh = new THREE.LineSegments(linesGeo, lineMat);
  group.add(linesMesh);

  // 5. Harness connector ring & backpack attachment straps
  const ringGeo = new THREE.TorusGeometry(0.2, 0.04, 8, 12);
  const ringMat = new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.9, roughness: 0.2 });
  const ring = new THREE.Mesh(ringGeo, ringMat);
  ring.position.copy(harnessCenter);
  group.add(ring);

  return group;
}

/**
 * Creates 3-12 part procedural tactical combatant (Player / Bot)
 */
export function createCharacterModel(
  isPlayer: boolean,
  jacketColor: number = isPlayer ? 0xef4444 : 0x0284c7,
  vestColor: number = 0x1f2937
): THREE.Group {
  const root = new THREE.Group();
  root.name = isPlayer ? 'PlayerRoot' : 'BotRoot';

  // 1. Torso / Combat tactical jacket
  const torsoGeo = new THREE.BoxGeometry(0.65, 0.75, 0.38);
  const jacketMat = new THREE.MeshStandardMaterial({
    color: jacketColor,
    roughness: 0.65,
    metalness: 0.1
  });
  const torso = new THREE.Mesh(torsoGeo, jacketMat);
  torso.position.y = 1.15;
  torso.castShadow = true;
  root.add(torso);

  // 2. Tactical Armor Plate Vest (Level 3 style)
  const vestGeo = new THREE.BoxGeometry(0.7, 0.55, 0.44);
  const vestMat = new THREE.MeshStandardMaterial({
    color: vestColor,
    roughness: 0.4,
    metalness: 0.4
  });
  const vest = new THREE.Mesh(vestGeo, vestMat);
  vest.position.set(0, 1.18, 0.02);
  vest.castShadow = true;
  root.add(vest);

  // 3. Vest ammo pouches (front detail)
  for (let i = -1; i <= 1; i++) {
    const pouchGeo = new THREE.BoxGeometry(0.14, 0.18, 0.08);
    const pouch = new THREE.Mesh(pouchGeo, MAT_TACTICAL_DARK);
    pouch.position.set(i * 0.18, 1.05, 0.25);
    root.add(pouch);
  }

  // 4. Head & Neck
  const neckGeo = new THREE.CylinderGeometry(0.12, 0.14, 0.15, 8);
  const neck = new THREE.Mesh(neckGeo, MAT_SKIN);
  neck.position.y = 1.6;
  root.add(neck);

  const headGeo = new THREE.SphereGeometry(0.22, 12, 10);
  headGeo.scale(0.9, 1.05, 0.95);
  const head = new THREE.Mesh(headGeo, MAT_SKIN);
  head.position.y = 1.78;
  head.name = 'Head'; // for headshot raycasting
  head.castShadow = true;
  root.add(head);

  // 5. Military Tactical Helmet
  const helmetGeo = new THREE.SphereGeometry(0.26, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.55);
  const helmet = new THREE.Mesh(helmetGeo, MAT_HELMET_MILITARY);
  helmet.position.set(0, 1.83, -0.01);
  helmet.castShadow = true;
  root.add(helmet);

  // 6. Goggles / Visor
  const visorGeo = new THREE.BoxGeometry(0.32, 0.1, 0.12);
  const visor = new THREE.Mesh(visorGeo, isPlayer ? MAT_VISOR_GOLD : MAT_TACTICAL_DARK);
  visor.position.set(0, 1.78, 0.18);
  root.add(visor);

  // 7. Tactical Military Backpack (Free Fire Lv.3 style)
  const backpackGeo = new THREE.BoxGeometry(0.5, 0.6, 0.28);
  const backpackMat = new THREE.MeshStandardMaterial({ color: 0x374151, roughness: 0.7, metalness: 0.2 });
  const backpack = new THREE.Mesh(backpackGeo, backpackMat);
  backpack.position.set(0, 1.2, -0.28);
  backpack.castShadow = true;
  root.add(backpack);

  // Antenna on backpack
  const antGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.4);
  const ant = new THREE.Mesh(antGeo, MAT_METAL_GUN);
  ant.position.set(0.18, 1.6, -0.3);
  root.add(ant);

  // 8. Hips & Combat Trousers
  const pelvisGeo = new THREE.BoxGeometry(0.58, 0.25, 0.34);
  const pelvis = new THREE.Mesh(pelvisGeo, MAT_TACTICAL_DARK);
  pelvis.position.y = 0.72;
  root.add(pelvis);

  // 9. Left & Right Legs
  const legGeo = new THREE.BoxGeometry(0.22, 0.55, 0.24);
  const legL = new THREE.Mesh(legGeo, MAT_TACTICAL_DARK);
  legL.position.set(-0.18, 0.42, 0);
  legL.name = 'LegL';
  legL.castShadow = true;
  root.add(legL);

  const legR = new THREE.Mesh(legGeo, MAT_TACTICAL_DARK);
  legR.position.set(0.18, 0.42, 0);
  legR.name = 'LegR';
  legR.castShadow = true;
  root.add(legR);

  // Knee guards
  const kneeGeo = new THREE.BoxGeometry(0.16, 0.12, 0.06);
  const kneeL = new THREE.Mesh(kneeGeo, MAT_HELMET_MILITARY);
  kneeL.position.set(-0.18, 0.42, 0.13);
  root.add(kneeL);
  const kneeR = new THREE.Mesh(kneeGeo, MAT_HELMET_MILITARY);
  kneeR.position.set(0.18, 0.42, 0.13);
  root.add(kneeR);

  // 10. Combat Boots
  const bootGeo = new THREE.BoxGeometry(0.24, 0.16, 0.32);
  const bootL = new THREE.Mesh(bootGeo, MAT_BOOTS);
  bootL.position.set(-0.18, 0.08, 0.04);
  bootL.castShadow = true;
  root.add(bootL);

  const bootR = new THREE.Mesh(bootGeo, MAT_BOOTS);
  bootR.position.set(0.18, 0.08, 0.04);
  bootR.castShadow = true;
  root.add(bootR);

  // 11. Arms container with hands for weapon holding
  const armGroup = new THREE.Group();
  armGroup.name = 'Arms';
  armGroup.position.set(0, 1.35, 0);

  const armGeo = new THREE.BoxGeometry(0.16, 0.45, 0.18);
  const armL = new THREE.Mesh(armGeo, jacketMat);
  armL.position.set(-0.4, -0.15, 0.1);
  armL.rotation.x = 0.5;
  armGroup.add(armL);

  const armR = new THREE.Mesh(armGeo, jacketMat);
  armR.position.set(0.4, -0.15, 0.15);
  armR.rotation.x = 0.8;
  armGroup.add(armR);

  // Hands / Gloves
  const gloveGeo = new THREE.BoxGeometry(0.12, 0.14, 0.14);
  const gloveL = new THREE.Mesh(gloveGeo, MAT_TACTICAL_DARK);
  gloveL.position.set(-0.25, -0.25, 0.35);
  armGroup.add(gloveL);

  const gloveR = new THREE.Mesh(gloveGeo, MAT_TACTICAL_DARK);
  gloveR.position.set(0.25, -0.22, 0.35);
  armGroup.add(gloveR);

  root.add(armGroup);

  // Weapon socket anchored to the right hand
  const weaponSocket = new THREE.Group();
  weaponSocket.name = 'WeaponSocket';
  weaponSocket.position.set(0.18, 1.15, 0.4);
  root.add(weaponSocket);

  return root;
}

/**
 * Creates weapon model for given WeaponType
 */
export function createWeaponModel(type: WeaponType): THREE.Group {
  const weapon = new THREE.Group();
  weapon.name = `Weapon_${type}`;

  if (type === 'AR') {
    // SCAR / M4 style Assault Rifle
    // Receiver & Body
    const bodyGeo = new THREE.BoxGeometry(0.08, 0.14, 0.65);
    const body = new THREE.Mesh(bodyGeo, MAT_METAL_GUN);
    weapon.add(body);

    // Barrel
    const barrelGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.4, 8);
    barrelGeo.rotateX(Math.PI / 2);
    const barrel = new THREE.Mesh(barrelGeo, MAT_METAL_GUN);
    barrel.position.set(0, 0.02, 0.45);
    weapon.add(barrel);

    // Muzzle flash anchor point
    const muzzle = new THREE.Object3D();
    muzzle.name = 'Muzzle';
    muzzle.position.set(0, 0.02, 0.68);
    weapon.add(muzzle);

    // Curved Banana Magazine
    const magGeo = new THREE.BoxGeometry(0.06, 0.22, 0.12);
    const mag = new THREE.Mesh(magGeo, MAT_TACTICAL_DARK);
    mag.position.set(0, -0.14, 0.08);
    mag.rotation.x = -0.2;
    weapon.add(mag);

    // Holographic Red Dot Sight
    const sightGeo = new THREE.BoxGeometry(0.06, 0.08, 0.12);
    const sight = new THREE.Mesh(sightGeo, MAT_GOLD_ACCENT);
    sight.position.set(0, 0.11, -0.05);
    weapon.add(sight);

    // Stock
    const stockGeo = new THREE.BoxGeometry(0.07, 0.16, 0.25);
    const stock = new THREE.Mesh(stockGeo, MAT_TACTICAL_DARK);
    stock.position.set(0, -0.02, -0.38);
    weapon.add(stock);

  } else if (type === 'SHOTGUN') {
    // M1887 Free Fire dual-barrel shotgun
    const barrel1 = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.6, 8), MAT_METAL_GUN);
    barrel1.geometry.rotateX(Math.PI / 2);
    barrel1.position.set(-0.02, 0.03, 0.25);
    weapon.add(barrel1);

    const barrel2 = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.6, 8), MAT_METAL_GUN);
    barrel2.geometry.rotateX(Math.PI / 2);
    barrel2.position.set(0.02, 0.03, 0.25);
    weapon.add(barrel2);

    const bodyGeo = new THREE.BoxGeometry(0.09, 0.14, 0.35);
    const body = new THREE.Mesh(bodyGeo, MAT_GOLD_ACCENT);
    weapon.add(body);

    const stockGeo = new THREE.BoxGeometry(0.08, 0.15, 0.3);
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.7 });
    const stock = new THREE.Mesh(stockGeo, woodMat);
    stock.position.set(0, -0.06, -0.28);
    stock.rotation.x = -0.15;
    weapon.add(stock);

    const muzzle = new THREE.Object3D();
    muzzle.name = 'Muzzle';
    muzzle.position.set(0, 0.03, 0.58);
    weapon.add(muzzle);

  } else if (type === 'SNIPER') {
    // AWM Long-range Sniper with huge scope
    const bodyGeo = new THREE.BoxGeometry(0.08, 0.15, 0.85);
    const body = new THREE.Mesh(bodyGeo, new THREE.MeshStandardMaterial({ color: 0x166534, roughness: 0.5 }));
    weapon.add(body);

    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.6, 8), MAT_METAL_GUN);
    barrel.geometry.rotateX(Math.PI / 2);
    barrel.position.set(0, 0.03, 0.65);
    weapon.add(barrel);

    // Muzzle brake
    const brake = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.03, 0.1, 8), MAT_METAL_GUN);
    brake.geometry.rotateX(Math.PI / 2);
    brake.position.set(0, 0.03, 0.96);
    weapon.add(brake);

    const muzzle = new THREE.Object3D();
    muzzle.name = 'Muzzle';
    muzzle.position.set(0, 0.03, 1.02);
    weapon.add(muzzle);

    // High magnification scope
    const scopeGeo = new THREE.CylinderGeometry(0.038, 0.045, 0.4, 12);
    scopeGeo.rotateX(Math.PI / 2);
    const scope = new THREE.Mesh(scopeGeo, MAT_METAL_GUN);
    scope.position.set(0, 0.14, 0.05);
    weapon.add(scope);

    // Scope lens
    const lens = new THREE.Mesh(new THREE.CircleGeometry(0.035, 12), MAT_VISOR_GOLD);
    lens.position.set(0, 0.14, 0.25);
    weapon.add(lens);

  } else if (type === 'KATANA') {
    // Japanese Katana Sword
    const bladeGeo = new THREE.BoxGeometry(0.02, 0.06, 0.95);
    const bladeMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.95, roughness: 0.1 });
    const blade = new THREE.Mesh(bladeGeo, bladeMat);
    blade.position.set(0, 0.02, 0.45);
    weapon.add(blade);

    // Guard (Tsuba)
    const tsuba = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.02, 12), MAT_GOLD_ACCENT);
    tsuba.position.set(0, 0.02, 0.0);
    tsuba.rotation.x = Math.PI / 2;
    weapon.add(tsuba);

    // Handle (Tsuka)
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.28, 8), MAT_TACTICAL_DARK);
    handle.rotation.x = Math.PI / 2;
    handle.position.set(0, 0.02, -0.15);
    weapon.add(handle);

  } else if (type === 'GLOO_WALL') {
    // Gloo Wall projector grenade canister
    const canGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.2, 10);
    const canMat = new THREE.MeshStandardMaterial({ color: 0x06b6d4, roughness: 0.2, metalness: 0.7, emissive: 0x0891b2, emissiveIntensity: 0.4 });
    const can = new THREE.Mesh(canGeo, canMat);
    weapon.add(can);
  }

  weapon.scale.set(0.85, 0.85, 0.85);
  return weapon;
}

/**
 * Creates Free Fire signature Gloo Wall (Ice bunker barricade)
 */
export function createGlooWallModel(): THREE.Group {
  const wall = new THREE.Group();
  wall.name = 'GlooWall';

  // Curved defensive arch geometry
  const width = 3.6;
  const height = 2.4;
  const segments = 7;

  // Ice cyan material with glowing edge
  const glooMat = new THREE.MeshStandardMaterial({
    color: 0x06b6d4,
    roughness: 0.2,
    metalness: 0.3,
    emissive: 0x0284c7,
    emissiveIntensity: 0.35,
    transparent: true,
    opacity: 0.92
  });

  const frameMat = new THREE.MeshStandardMaterial({
    color: 0x082f49,
    roughness: 0.5,
    metalness: 0.6
  });

  // Build curved wall panels
  for (let i = 0; i < segments; i++) {
    const angle = (i / (segments - 1) - 0.5) * 1.2;
    const panelGeo = new THREE.BoxGeometry(width / segments + 0.05, height, 0.35);
    const panel = new THREE.Mesh(panelGeo, glooMat);
    panel.position.set(
      Math.sin(angle) * 2.2,
      height / 2,
      Math.cos(angle) * 2.2 - 2.2
    );
    panel.rotation.y = angle;
    panel.castShadow = true;
    panel.receiveShadow = true;
    wall.add(panel);
  }

  // Top blast rim
  const topGeo = new THREE.CylinderGeometry(2.3, 2.3, 0.2, 16, 1, true, -0.6, 1.2);
  const topRim = new THREE.Mesh(topGeo, frameMat);
  topRim.position.set(0, height, -2.2);
  wall.add(topRim);

  // Free Fire emblem glow core on front
  const emblemGeo = new THREE.BoxGeometry(0.6, 0.6, 0.08);
  const emblemMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    emissive: 0x38bdf8,
    emissiveIntensity: 0.8,
    roughness: 0.1
  });
  const emblem = new THREE.Mesh(emblemGeo, emblemMat);
  emblem.position.set(0, 1.2, 0.2);
  wall.add(emblem);

  return wall;
}

/**
 * Creates Loot Supply Crate / Airdrop
 */
export function createLootCrateModel(type: 'AIRDROP' | 'CRATE' | 'DEATH_CRATE'): THREE.Group {
  const crate = new THREE.Group();

  if (type === 'AIRDROP') {
    // Red military airdrop container with yellow warning stripes
    const boxGeo = new THREE.BoxGeometry(1.6, 1.4, 1.6);
    const boxMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.5, metalness: 0.4 });
    const box = new THREE.Mesh(boxGeo, boxMat);
    box.position.y = 0.7;
    box.castShadow = true;
    crate.add(box);

    // Frame reinforced edges
    const edgeGeo = new THREE.BoxGeometry(1.68, 0.16, 1.68);
    const edgeMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.4, metalness: 0.7 });
    const edgeTop = new THREE.Mesh(edgeGeo, edgeMat);
    edgeTop.position.y = 1.35;
    crate.add(edgeTop);

    // Yellow folded parachute fabric on top
    const clothGeo = new THREE.SphereGeometry(0.7, 8, 6, 0, Math.PI * 2, 0, Math.PI * 0.4);
    const clothMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.8 });
    const cloth = new THREE.Mesh(clothGeo, clothMat);
    cloth.position.y = 1.4;
    crate.add(cloth);

    // Red smoke beacon
    const beaconGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.4, 8);
    const beaconMat = new THREE.MeshStandardMaterial({ color: 0xff0000, emissive: 0xff0000, emissiveIntensity: 1.0 });
    const beacon = new THREE.Mesh(beaconGeo, beaconMat);
    beacon.position.set(0.6, 1.6, 0.6);
    crate.add(beacon);

  } else if (type === 'DEATH_CRATE') {
    // Green/gold loot box left by eliminated players
    const boxGeo = new THREE.BoxGeometry(0.9, 0.7, 0.9);
    const boxMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.4, metalness: 0.5 });
    const box = new THREE.Mesh(boxGeo, boxMat);
    box.position.y = 0.35;
    box.castShadow = true;
    crate.add(box);

    // Glowing skull/cross crest
    const crestGeo = new THREE.BoxGeometry(0.3, 0.05, 0.3);
    const crestMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, emissive: 0xeab308, emissiveIntensity: 0.8 });
    const crest = new THREE.Mesh(crestGeo, crestMat);
    crest.position.y = 0.72;
    crate.add(crest);

  } else {
    // Standard tactical ammo/health crate
    const boxGeo = new THREE.BoxGeometry(1.0, 0.6, 0.7);
    const boxMat = new THREE.MeshStandardMaterial({ color: 0x3f6212, roughness: 0.6, metalness: 0.3 });
    const box = new THREE.Mesh(boxGeo, boxMat);
    box.position.y = 0.3;
    box.castShadow = true;
    crate.add(box);

    // Stencil strap
    const strapGeo = new THREE.BoxGeometry(1.04, 0.1, 0.74);
    const strapMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.5 });
    const strap = new THREE.Mesh(strapGeo, strapMat);
    strap.position.y = 0.3;
    crate.add(strap);
  }

  return crate;
}

/**
 * Creates 3-part composite Tree
 */
export function createTreeModel(scale: number = 1.0): THREE.Group {
  const tree = new THREE.Group();

  // Trunk
  const trunkGeo = new THREE.CylinderGeometry(0.25 * scale, 0.4 * scale, 2.2 * scale, 7);
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5c3a21, roughness: 0.9, metalness: 0.05 });
  const trunk = new THREE.Mesh(trunkGeo, trunkMat);
  trunk.position.y = 1.1 * scale;
  trunk.castShadow = true;
  tree.add(trunk);

  // 3-tiered conical foliage
  const foliageMat1 = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.8, metalness: 0.05 });
  const foliageMat2 = new THREE.MeshStandardMaterial({ color: 0x16a34a, roughness: 0.8, metalness: 0.05 });
  const foliageMat3 = new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.8, metalness: 0.05 });

  const f1 = new THREE.Mesh(new THREE.ConeGeometry(1.8 * scale, 2.0 * scale, 7), foliageMat1);
  f1.position.y = 2.4 * scale;
  f1.castShadow = true;
  tree.add(f1);

  const f2 = new THREE.Mesh(new THREE.ConeGeometry(1.4 * scale, 1.8 * scale, 7), foliageMat2);
  f2.position.y = 3.4 * scale;
  f2.castShadow = true;
  tree.add(f2);

  const f3 = new THREE.Mesh(new THREE.ConeGeometry(0.9 * scale, 1.5 * scale, 7), foliageMat3);
  f3.position.y = 4.3 * scale;
  f3.castShadow = true;
  tree.add(f3);

  return tree;
}

/**
 * Creates Polyhedral Rock
 */
export function createRockModel(scale: number = 1.0): THREE.Group {
  const rock = new THREE.Group();
  const geo = new THREE.DodecahedronGeometry(1.2 * scale, 1);
  geo.scale(1.2, 0.75, 1.0);
  const mat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.85, metalness: 0.15 });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.6 * scale;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  rock.add(mesh);
  return rock;
}

/**
 * Creates Military Watchtower
 */
export function createWatchtowerModel(): THREE.Group {
  const tower = new THREE.Group();
  const legMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4, metalness: 0.8 });
  const woodMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.85, metalness: 0.1 });

  // 4 steel support legs
  const legHeight = 7.0;
  const legPositions = [
    [-1.6, -1.6], [1.6, -1.6], [-1.6, 1.6], [1.6, 1.6]
  ];

  legPositions.forEach(([x, z]) => {
    const legGeo = new THREE.CylinderGeometry(0.08, 0.12, legHeight, 6);
    const leg = new THREE.Mesh(legGeo, legMat);
    leg.position.set(x, legHeight / 2, z);
    leg.castShadow = true;
    tower.add(leg);
  });

  // Cross bracing
  const braceMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.6, roughness: 0.5 });
  for (let h = 2.0; h < 6.5; h += 2.2) {
    const ringGeo = new THREE.BoxGeometry(3.3, 0.08, 3.3);
    const ring = new THREE.Mesh(ringGeo, braceMat);
    ring.position.y = h;
    tower.add(ring);
  }

  // Wooden Platform Deck
  const deckGeo = new THREE.BoxGeometry(4.2, 0.3, 4.2);
  const deck = new THREE.Mesh(deckGeo, woodMat);
  deck.position.y = legHeight;
  deck.castShadow = true;
  deck.receiveShadow = true;
  tower.add(deck);

  // Railing
  const railGeo = new THREE.BoxGeometry(4.0, 0.9, 0.1);
  const rFront = new THREE.Mesh(railGeo, legMat);
  rFront.position.set(0, legHeight + 0.5, 1.95);
  tower.add(rFront);
  const rBack = new THREE.Mesh(railGeo, legMat);
  rBack.position.set(0, legHeight + 0.5, -1.95);
  tower.add(rBack);

  // Roof Canopy
  const roofGeo = new THREE.ConeGeometry(3.4, 1.2, 4);
  roofGeo.rotateY(Math.PI / 4);
  const roofMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.5, metalness: 0.6 });
  const roof = new THREE.Mesh(roofGeo, roofMat);
  roof.position.y = legHeight + 3.2;
  roof.castShadow = true;
  tower.add(roof);

  return tower;
}

/**
 * Creates Military Building / Bunker
 */
export function createBunkerBuildingModel(w: number = 8, h: number = 4, d: number = 6): THREE.Group {
  const building = new THREE.Group();
  const concreteMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.8, metalness: 0.2 });
  const metalRoofMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4, metalness: 0.7 });

  // Main concrete structure
  const wallGeo = new THREE.BoxGeometry(w, h, d);
  const walls = new THREE.Mesh(wallGeo, concreteMat);
  walls.position.y = h / 2;
  walls.castShadow = true;
  walls.receiveShadow = true;
  building.add(walls);

  // Corrugated roof trim
  const roofGeo = new THREE.BoxGeometry(w + 0.6, 0.35, d + 0.6);
  const roof = new THREE.Mesh(roofGeo, metalRoofMat);
  roof.position.y = h + 0.17;
  roof.castShadow = true;
  building.add(roof);

  // Doorway recess
  const doorGeo = new THREE.BoxGeometry(1.6, 2.4, 0.2);
  const doorMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9 });
  const door = new THREE.Mesh(doorGeo, doorMat);
  door.position.set(0, 1.2, d / 2 + 0.05);
  building.add(door);

  // Sandbag barricade in front
  const sandbagMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.95 });
  for (let i = -1; i <= 1; i += 2) {
    const bagGeo = new THREE.BoxGeometry(1.8, 0.8, 0.6);
    const bag = new THREE.Mesh(bagGeo, sandbagMat);
    bag.position.set(i * 2.2, 0.4, d / 2 + 1.0);
    bag.castShadow = true;
    building.add(bag);
  }

  return building;
}
