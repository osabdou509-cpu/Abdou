/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

export type GameState = 'TITLE' | 'PARACHUTING' | 'PLAYING' | 'PAUSED' | 'VICTORY' | 'GAMEOVER';

export type WeaponType = 'AR' | 'SHOTGUN' | 'SNIPER' | 'KATANA' | 'GLOO_WALL';

export interface WeaponDef {
  type: WeaponType;
  name: string;
  nameAr: string;
  damage: number;
  fireRate: number; // seconds between shots
  magazineSize: number;
  reloadTime: number;
  range: number;
  spread: number;
  pellets?: number;
  automatic: boolean;
  ammoType: string;
}

export interface WeaponState {
  type: WeaponType;
  currentAmmo: number;
  reserveAmmo: number;
  lastFiredTime: number;
  isReloading: boolean;
  reloadStartTime: number;
}

export interface CharacterEntity {
  id: string;
  name: string;
  isPlayer: boolean;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  rotation: THREE.Euler;
  health: number;
  maxHealth: number;
  armor: number;
  maxArmor: number;
  isAlive: boolean;
  isGrounded: boolean;
  isParachuting: boolean;
  parachuteDeployed: boolean;
  altitude: number;
  glideSpeed: number;
  kills: number;
  currentWeaponIndex: number;
  weapons: WeaponState[];
  glooWallsCount: number;
  medkitsCount: number;
  meshGroup: THREE.Group;
  parachuteMesh?: THREE.Group;
  // Bot AI specific
  targetPos?: THREE.Vector3;
  attackTarget?: CharacterEntity | null;
  aiState?: 'DROP' | 'LOOT' | 'PATROL' | 'COMBAT' | 'FLEE_STORM';
  aiTimer?: number;
  shootCooldown?: number;
}

export interface BulletTracer {
  id: string;
  start: THREE.Vector3;
  end: THREE.Vector3;
  current: THREE.Vector3;
  direction: THREE.Vector3;
  speed: number;
  damage: number;
  ownerId: string;
  isPlayer: boolean;
  mesh: THREE.Line | THREE.Mesh;
  alive: boolean;
}

export interface DamageNumber {
  id: string;
  text: string;
  position: THREE.Vector3;
  color: string;
  lifetime: number;
  maxLifetime: number;
  isHeadshot: boolean;
}

export interface LootCrate {
  id: string;
  position: THREE.Vector3;
  type: 'AMMO' | 'MEDKIT' | 'ARMOR' | 'WEAPON' | 'AIRDROP' | 'DEATH_CRATE';
  contentName: string;
  mesh: THREE.Group;
  pickedUp: boolean;
}

export interface GlooWall {
  id: string;
  position: THREE.Vector3;
  rotation: THREE.Euler;
  health: number;
  maxHealth: number;
  mesh: THREE.Group;
  ownerId: string;
  timestamp: number;
}

export interface SafeZone {
  center: THREE.Vector2;
  currentRadius: number;
  targetRadius: number;
  targetCenter: THREE.Vector2;
  shrinkStartTime: number;
  shrinkDuration: number;
  phase: number;
  maxPhases: number;
  damagePerSec: number;
  isShrinking: boolean;
  timeUntilNextShrink: number;
}

export interface KillFeedItem {
  id: string;
  killerName: string;
  victimName: string;
  weaponName: string;
  isHeadshot: boolean;
  isPlayerInvolved: boolean;
  timestamp: number;
}

export interface MatchStats {
  kills: number;
  headshots: number;
  damageDealt: number;
  damageTaken: number;
  survivalTimeSec: number;
  rank: number;
  totalCombatants: number;
}
