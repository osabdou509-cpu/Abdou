/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  CharacterEntity,
  GameState,
  WeaponType,
  BulletTracer,
  DamageNumber,
  GlooWall,
  SafeZone,
  KillFeedItem,
  MatchStats
} from './types';
import { WEAPON_DEFINITIONS } from './weapons';
import {
  createCharacterModel,
  createParachuteModel,
  createWeaponModel,
  createGlooWallModel,
  createLootCrateModel
} from './models';
import { buildWorld, getTerrainHeight, ISLAND_RADIUS, WorldBuildResult } from './world';
import { sounds } from './audio';

// Pre-allocated math objects to eliminate Garbage Collection (GC) in animation loop
const _vec3A = new THREE.Vector3();
const _vec3B = new THREE.Vector3();
const _vec3C = new THREE.Vector3();
const _camOffset = new THREE.Vector3();
const _raycaster = new THREE.Raycaster();
const _screenCenter = new THREE.Vector2(0, 0);

const BOT_NAMES = [
  'Striker_99', 'GhostRider', 'Hayato_PRO', 'Kelly_Rush', 'Alok_Beats',
  'Chrono_07', 'Viper_X', 'Shadow_Ninja', 'Sniper_Wolf', 'Falcon_Eye',
  'Thunder_Bolt', 'Ragnarok', 'Cobra_Fang', 'Blaze_Fire', 'Titan_Shield',
  'Nova_Warrior', 'Apex_Predator'
];

export interface EngineCallbacks {
  onStateChange: (state: GameState) => void;
  onPlayerHealthChange: (hp: number, maxHp: number, armor: number, maxArmor: number) => void;
  onWeaponChange: (weapon: WeaponType, ammo: number, reserve: number, isReloading: boolean) => void;
  onGlooCountChange: (count: number) => void;
  onMedkitCountChange: (count: number) => void;
  onAliveCountChange: (alive: number, kills: number) => void;
  onAltitudeChange: (altitude: number, speed: number, isParachuting: boolean) => void;
  onSafeZoneChange: (zone: SafeZone) => void;
  onKillFeedItem: (item: KillFeedItem) => void;
  onDamageNumber: (dmg: DamageNumber) => void;
  onHitMarker: (isHeadshot: boolean) => void;
  onMatchEnd: (victory: boolean, stats: MatchStats) => void;
  onMinimapUpdate: (playerPos: THREE.Vector3, playerYaw: number, enemies: { pos: THREE.Vector3; firing: boolean }[]) => void;
}

export class GameEngine {
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;
  private container: HTMLElement;
  private callbacks: EngineCallbacks;
  private clock: THREE.Clock;
  private isSoftwareGl: boolean = false;
  private frameId: number = 0;
  private isDisposed: boolean = false;

  // World and actors
  public world!: WorldBuildResult;
  public player!: CharacterEntity;
  public bots: CharacterEntity[] = [];
  public bullets: BulletTracer[] = [];
  public glooWalls: GlooWall[] = [];
  public damageNumbers: DamageNumber[] = [];
  public safeZone!: SafeZone;

  // Game state
  public state: GameState = 'TITLE';
  public stats: MatchStats = {
    kills: 0,
    headshots: 0,
    damageDealt: 0,
    damageTaken: 0,
    survivalTimeSec: 0,
    rank: 18,
    totalCombatants: 18
  };

  // Input states
  public keys: Record<string, boolean> = {
    forward: false,
    backward: false,
    left: false,
    right: false,
    jump: false,
    sprint: false,
    crouch: false,
    shoot: false,
    aim: false
  };

  // Camera angles
  public yaw: number = 0;
  public pitch: number = 0;
  private isPointerLocked: boolean = false;
  public cameraDistance: number = 4.2;
  public cameraHeight: number = 1.75;
  private screenShake: number = 0;

  // Parachute specifics
  public parachuteDeployAltitude: number = 160;
  public parachuteTouchdownThreshold: number = 1.3;

  constructor(container: HTMLElement, callbacks: EngineCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.clock = new THREE.Clock();

    // 1. Detect software WebGL
    this.isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    // 2. Initialize Three.js Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance'
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(this.renderer.domElement);

    // 3. Scene & Camera
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x7dd3fc); // vivid sky blue
    this.scene.fog = new THREE.FogExp2(0x7dd3fc, 0.0045); // horizon fog fade

    this.camera = new THREE.PerspectiveCamera(
      65,
      container.clientWidth / container.clientHeight,
      0.1,
      800
    );

    // 4. Studio Environment Reflection via RoomEnvironment
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    // 5. Lighting: Warm sun directional light with tight shadows + cool hemisphere
    const sunLight = new THREE.DirectionalLight(0xfff7ed, 2.2);
    sunLight.position.set(60, 140, 50);
    if (!this.isSoftwareGl) {
      sunLight.castShadow = true;
      sunLight.shadow.mapSize.width = 2048;
      sunLight.shadow.mapSize.height = 2048;
      sunLight.shadow.camera.near = 10;
      sunLight.shadow.camera.far = 320;
      const d = 90;
      sunLight.shadow.camera.left = -d;
      sunLight.shadow.camera.right = d;
      sunLight.shadow.camera.top = d;
      sunLight.shadow.camera.bottom = -d;
      sunLight.shadow.bias = -0.0004;
      sunLight.shadow.normalBias = 0.02;
    }
    this.scene.add(sunLight);

    const hemiLight = new THREE.HemisphereLight(0xbae6fd, 0x365314, 0.9);
    this.scene.add(hemiLight);

    // 6. Build World
    this.world = buildWorld(this.scene);

    // 7. Setup Safe Zone data
    this.safeZone = {
      center: new THREE.Vector2(0, 0),
      currentRadius: ISLAND_RADIUS,
      targetRadius: ISLAND_RADIUS * 0.65,
      targetCenter: new THREE.Vector2(0, 0),
      shrinkStartTime: 40,
      shrinkDuration: 30,
      phase: 1,
      maxPhases: 4,
      damagePerSec: 5,
      isShrinking: false,
      timeUntilNextShrink: 45
    };

    // 8. Setup Inputs & Resize Listeners
    this.setupEventListeners();

    // 9. Pre-warm shaders
    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    // 10. Start Game Loop
    this.startLoop();
  }

  /**
   * Initializes a new Battle Royale match with Parachute Sky Drop!
   */
  public startMatch() {
    this.state = 'PARACHUTING';
    this.callbacks.onStateChange(this.state);
    sounds.startWind(0.85);
    sounds.playParachuteDeploy();

    // Clear previous entities if any
    if (this.player) {
      this.scene.remove(this.player.meshGroup);
    }
    this.bots.forEach(b => this.scene.remove(b.meshGroup));
    this.bots = [];
    this.bullets.forEach(b => this.scene.remove(b.mesh));
    this.bullets = [];
    this.glooWalls.forEach(g => this.scene.remove(g.mesh));
    this.glooWalls = [];
    this.damageNumbers = [];

    // Reset stats
    this.stats = {
      kills: 0,
      headshots: 0,
      damageDealt: 0,
      damageTaken: 0,
      survivalTimeSec: 0,
      rank: 18,
      totalCombatants: 18
    };

    // Reset safe zone
    this.safeZone = {
      center: new THREE.Vector2(0, 0),
      currentRadius: ISLAND_RADIUS,
      targetRadius: 95,
      targetCenter: new THREE.Vector2((Math.random() - 0.5) * 30, (Math.random() - 0.5) * 30),
      shrinkStartTime: 45,
      shrinkDuration: 35,
      phase: 1,
      maxPhases: 4,
      damagePerSec: 4,
      isShrinking: false,
      timeUntilNextShrink: 45
    };

    // 1. Create Player Entity in Sky (Altitude 160m)
    const playerMesh = createCharacterModel(true, 0xef4444, 0x1f2937);
    const playerParachute = createParachuteModel(0xff3b00);
    playerMesh.add(playerParachute);
    this.scene.add(playerMesh);

    this.player = {
      id: 'player_hero',
      name: 'Player',
      isPlayer: true,
      position: new THREE.Vector3(0, 160, 0),
      velocity: new THREE.Vector3(0, -12, 0),
      rotation: new THREE.Euler(0, 0, 0, 'YXZ'),
      health: 200,
      maxHealth: 200,
      armor: 100,
      maxArmor: 100,
      isAlive: true,
      isGrounded: false,
      isParachuting: true,
      parachuteDeployed: true,
      altitude: 160,
      glideSpeed: 18,
      kills: 0,
      currentWeaponIndex: 0,
      weapons: [
        { type: 'AR', currentAmmo: 30, reserveAmmo: 120, lastFiredTime: 0, isReloading: false, reloadStartTime: 0 },
        { type: 'SHOTGUN', currentAmmo: 2, reserveAmmo: 20, lastFiredTime: 0, isReloading: false, reloadStartTime: 0 },
        { type: 'SNIPER', currentAmmo: 5, reserveAmmo: 15, lastFiredTime: 0, isReloading: false, reloadStartTime: 0 },
        { type: 'KATANA', currentAmmo: 999, reserveAmmo: 999, lastFiredTime: 0, isReloading: false, reloadStartTime: 0 }
      ],
      glooWallsCount: 3,
      medkitsCount: 2,
      meshGroup: playerMesh,
      parachuteMesh: playerParachute
    };

    // Attach initial weapon to socket
    this.updateCharacterWeaponVisual(this.player);

    // 2. Create 17 Bot combatants also parachuting down across the map
    for (let i = 0; i < 17; i++) {
      const botMesh = createCharacterModel(false, 0x0284c7, 0x334155);
      const botChute = createParachuteModel(0x0284c7);
      botMesh.add(botChute);
      this.scene.add(botMesh);

      const spawnPoint = this.world.spawnPoints[i + 1] || new THREE.Vector3(
        (Math.random() - 0.5) * 120,
        155 + Math.random() * 15,
        (Math.random() - 0.5) * 120
      );

      const bot: CharacterEntity = {
        id: `bot_${i}`,
        name: BOT_NAMES[i] || `Survivor_${i + 1}`,
        isPlayer: false,
        position: spawnPoint.clone(),
        velocity: new THREE.Vector3((Math.random() - 0.5) * 4, -12, (Math.random() - 0.5) * 4),
        rotation: new THREE.Euler(0, Math.random() * Math.PI * 2, 0, 'YXZ'),
        health: 200,
        maxHealth: 200,
        armor: 50,
        maxArmor: 100,
        isAlive: true,
        isGrounded: false,
        isParachuting: true,
        parachuteDeployed: true,
        altitude: spawnPoint.y,
        glideSpeed: 14 + Math.random() * 6,
        kills: 0,
        currentWeaponIndex: 0,
        weapons: [
          { type: 'AR', currentAmmo: 30, reserveAmmo: 60, lastFiredTime: 0, isReloading: false, reloadStartTime: 0 }
        ],
        glooWallsCount: 1,
        medkitsCount: 1,
        meshGroup: botMesh,
        parachuteMesh: botChute,
        aiState: 'DROP',
        aiTimer: Math.random() * 3,
        shootCooldown: 0.5 + Math.random() * 1.5
      };

      this.updateCharacterWeaponVisual(bot);
      this.bots.push(bot);
    }

    // Update UI callbacks
    this.syncAllHUD();
  }

  private updateCharacterWeaponVisual(char: CharacterEntity) {
    const socket = char.meshGroup.getObjectByName('WeaponSocket');
    if (!socket) return;

    // Clear existing weapon
    while (socket.children.length > 0) {
      socket.remove(socket.children[0]);
    }

    const currentWep = char.weapons[char.currentWeaponIndex];
    if (currentWep) {
      const wepMesh = createWeaponModel(currentWep.type);
      socket.add(wepMesh);
    }
  }

  private setupEventListeners() {
    const onKeyDown = (e: KeyboardEvent) => {
      switch (e.code) {
        case 'KeyW': case 'ArrowUp': this.keys.forward = true; break;
        case 'KeyS': case 'ArrowDown': this.keys.backward = true; break;
        case 'KeyA': case 'ArrowLeft': this.keys.left = true; break;
        case 'KeyD': case 'ArrowRight': this.keys.right = true; break;
        case 'Space': this.keys.jump = true; break;
        case 'ShiftLeft': case 'ShiftRight': this.keys.sprint = true; break;
        case 'KeyC': this.keys.crouch = !this.keys.crouch; break;
        case 'KeyR': this.reloadCurrentWeapon(); break;
        case 'KeyG': this.deployGlooWall(); break;
        case 'KeyH': this.useMedkit(); break;
        case 'Digit1': this.switchWeapon(0); break;
        case 'Digit2': this.switchWeapon(1); break;
        case 'Digit3': this.switchWeapon(2); break;
        case 'Digit4': this.switchWeapon(3); break;
        case 'Escape':
          if (this.state === 'PLAYING') {
            this.state = 'PAUSED';
            this.callbacks.onStateChange(this.state);
          } else if (this.state === 'PAUSED') {
            this.state = 'PLAYING';
            this.callbacks.onStateChange(this.state);
          }
          break;
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      switch (e.code) {
        case 'KeyW': case 'ArrowUp': this.keys.forward = false; break;
        case 'KeyS': case 'ArrowDown': this.keys.backward = false; break;
        case 'KeyA': case 'ArrowLeft': this.keys.left = false; break;
        case 'KeyD': case 'ArrowRight': this.keys.right = false; break;
        case 'Space': this.keys.jump = false; break;
        case 'ShiftLeft': case 'ShiftRight': this.keys.sprint = false; break;
      }
    };

    const onMouseDown = (e: MouseEvent) => {
      if (this.state === 'TITLE') return;
      if (e.button === 0) {
        this.keys.shoot = true;
      } else if (e.button === 2) {
        this.keys.aim = true;
      }
    };

    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 0) this.keys.shoot = false;
      if (e.button === 2) this.keys.aim = false;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!this.isPointerLocked && this.state !== 'PARACHUTING' && this.state !== 'PLAYING') return;

      const sensitivity = 0.0022;
      this.yaw -= e.movementX * sensitivity;
      this.pitch -= e.movementY * sensitivity;
      // Clamp pitch so camera doesn't flip
      this.pitch = Math.max(-Math.PI * 0.42, Math.min(Math.PI * 0.42, this.pitch));
    };

    const onPointerLockChange = () => {
      this.isPointerLocked = document.pointerLockElement === this.renderer.domElement;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', () => {
      // Clear held keys on blur
      Object.keys(this.keys).forEach(k => { this.keys[k] = false; });
    });
    this.renderer.domElement.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);
    document.addEventListener('pointerlockchange', onPointerLockChange);

    const onResize = () => {
      if (this.isDisposed) return;
      const w = this.container.clientWidth;
      const h = this.container.clientHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);
  }

  public requestPointerLock() {
    try {
      this.renderer.domElement.requestPointerLock();
    } catch {}
  }

  public exitPointerLock() {
    try {
      if (document.exitPointerLock) document.exitPointerLock();
    } catch {}
  }

  public switchWeapon(index: number) {
    if (!this.player || !this.player.weapons[index]) return;
    this.player.currentWeaponIndex = index;
    this.updateCharacterWeaponVisual(this.player);
    const wep = this.player.weapons[index];
    this.callbacks.onWeaponChange(wep.type, wep.currentAmmo, wep.reserveAmmo, wep.isReloading);
    sounds.playReload();
  }

  public reloadCurrentWeapon() {
    if (!this.player || this.player.isParachuting || !this.player.isAlive) return;
    const wepState = this.player.weapons[this.player.currentWeaponIndex];
    const wepDef = WEAPON_DEFINITIONS[wepState.type];

    if (wepState.isReloading || wepState.currentAmmo === wepDef.magazineSize || wepState.reserveAmmo <= 0) {
      return;
    }

    wepState.isReloading = true;
    wepState.reloadStartTime = this.clock.getElapsedTime();
    sounds.playReload();
    this.callbacks.onWeaponChange(wepState.type, wepState.currentAmmo, wepState.reserveAmmo, true);
  }

  public deployGlooWall() {
    if (!this.player || this.player.isParachuting || !this.player.isAlive || this.player.glooWallsCount <= 0) {
      return;
    }

    // Deploy instant defensive ice bunker in front of player
    this.player.glooWallsCount--;
    this.callbacks.onGlooCountChange(this.player.glooWallsCount);

    const wallMesh = createGlooWallModel();
    _forwardVector(this.yaw, _vec3A);
    const spawnPos = this.player.position.clone().addScaledVector(_vec3A, 2.5);
    spawnPos.y = getTerrainHeight(spawnPos.x, spawnPos.z);

    wallMesh.position.copy(spawnPos);
    wallMesh.rotation.y = this.yaw;
    this.scene.add(wallMesh);

    this.glooWalls.push({
      id: `gloo_${Date.now()}`,
      position: spawnPos,
      rotation: wallMesh.rotation.clone(),
      health: 450,
      maxHealth: 450,
      mesh: wallMesh,
      ownerId: this.player.id,
      timestamp: this.clock.getElapsedTime()
    });

    sounds.playGlooWallDeploy();
  }

  public useMedkit() {
    if (!this.player || this.player.isParachuting || !this.player.isAlive || this.player.medkitsCount <= 0) {
      return;
    }
    if (this.player.health >= this.player.maxHealth && this.player.armor >= this.player.maxArmor) {
      return;
    }

    this.player.medkitsCount--;
    this.player.health = Math.min(this.player.maxHealth, this.player.health + 85);
    this.player.armor = Math.min(this.player.maxArmor, this.player.armor + 50);
    sounds.playMedkitUse();
    this.callbacks.onMedkitCountChange(this.player.medkitsCount);
    this.callbacks.onPlayerHealthChange(this.player.health, this.player.maxHealth, this.player.armor, this.player.maxArmor);
  }

  private startLoop() {
    let lastTime = performance.now();

    const tick = () => {
      if (this.isDisposed) return;

      const now = performance.now();
      const rawDt = (now - lastTime) / 1000;
      lastTime = now;
      const dt = Math.min(rawDt, 0.05); // clamp delta time for stability

      this.update(dt);
      this.render();

      this.frameId = requestAnimationFrame(tick);
    };

    this.frameId = requestAnimationFrame(tick);
  }

  private update(dt: number) {
    if (this.state === 'PAUSED' || this.state === 'TITLE') {
      // Ambient camera orbit in title screen
      if (this.state === 'TITLE') {
        const time = this.clock.getElapsedTime() * 0.25;
        this.camera.position.set(Math.sin(time) * 85, 45, Math.cos(time) * 85);
        this.camera.lookAt(0, 10, 0);
      }
      return;
    }

    this.stats.survivalTimeSec += dt;

    // 1. Update Safe Zone Shrink & Storm
    this.updateSafeZone(dt);

    // 2. Update Player (Parachuting or Combat)
    if (this.player && this.player.isAlive) {
      if (this.player.isParachuting) {
        this.updateParachuting(this.player, dt);
      } else {
        this.updatePlayerMovement(dt);
        this.updatePlayerShooting(dt);
      }
    }

    // 3. Update Bots (Parachuting & Combat AI)
    this.updateBots(dt);

    // 4. Update Bullets & Tracers
    this.updateBullets(dt);

    // 5. Update Gloo Walls & Loot Crates
    this.updateGlooWalls(dt);
    this.checkLootPickups();

    // 6. Camera Follow & Smooth Damping
    this.updateCamera(dt);

    // 7. Minimap and HUD sync
    this.syncMinimap();
  }

  /**
   * Free Fire Parachute Descent Physics & Mechanics
   */
  private updateParachuting(char: CharacterEntity, dt: number) {
    const terrainH = getTerrainHeight(char.position.x, char.position.z);
    char.altitude = char.position.y - terrainH;

    // Parachute descent speed: faster dive if holding Shift/down
    let verticalSpeed = 12.0; // standard glide speed
    let horizontalSpeed = char.glideSpeed;

    if (char.isPlayer) {
      if (this.keys.sprint || this.keys.backward) {
        verticalSpeed = 24.0; // fast-dive
        horizontalSpeed = 24.0;
        sounds.updateWind(1.0);
      } else {
        sounds.updateWind(0.55);
      }

      // Air steering
      _forwardVector(this.yaw, _vec3A);
      _rightVector(this.yaw, _vec3B);

      const moveDir = _vec3C.set(0, 0, 0);
      if (this.keys.forward) moveDir.add(_vec3A);
      if (this.keys.backward) moveDir.sub(_vec3A);
      if (this.keys.left) moveDir.sub(_vec3B);
      if (this.keys.right) moveDir.add(_vec3B);

      if (moveDir.lengthSq() > 0.001) {
        moveDir.normalize();
        char.position.x += moveDir.x * horizontalSpeed * dt;
        char.position.z += moveDir.z * horizontalSpeed * dt;
        char.rotation.y = this.yaw;
      }

      // Canopy dynamic banking / sway
      if (char.parachuteMesh) {
        const targetRoll = this.keys.left ? 0.25 : (this.keys.right ? -0.25 : 0);
        char.parachuteMesh.rotation.z = THREE.MathUtils.damp(char.parachuteMesh.rotation.z, targetRoll, 6, dt);
        const targetPitch = this.keys.forward ? -0.2 : (this.keys.backward ? 0.3 : 0);
        char.parachuteMesh.rotation.x = THREE.MathUtils.damp(char.parachuteMesh.rotation.x, targetPitch, 6, dt);
      }

      this.callbacks.onAltitudeChange(char.altitude, horizontalSpeed + verticalSpeed, true);
    } else {
      // Bot glide towards designated landing spot
      if (char.targetPos) {
        const toTarget = _vec3A.subVectors(char.targetPos, char.position);
        toTarget.y = 0;
        if (toTarget.lengthSq() > 4) {
          toTarget.normalize();
          char.position.x += toTarget.x * horizontalSpeed * dt;
          char.position.z += toTarget.z * horizontalSpeed * dt;
          char.rotation.y = Math.atan2(toTarget.x, toTarget.z);
        }
      }
    }

    // Apply descent
    char.position.y -= verticalSpeed * dt;
    char.meshGroup.position.copy(char.position);

    // Touchdown Check!
    if (char.altitude <= this.parachuteTouchdownThreshold) {
      char.isParachuting = false;
      char.parachuteDeployed = false;
      char.position.y = terrainH;
      char.meshGroup.position.copy(char.position);

      // Detach and discard parachute canopy
      if (char.parachuteMesh) {
        char.meshGroup.remove(char.parachuteMesh);
        char.parachuteMesh = undefined;
      }

      if (char.isPlayer) {
        sounds.stopWind();
        sounds.playLandThud();
        this.state = 'PLAYING';
        this.callbacks.onStateChange(this.state);
        this.callbacks.onAltitudeChange(0, 0, false);
      }
    }
  }

  /**
   * Player Ground Combat Movement
   */
  private updatePlayerMovement(dt: number) {
    const terrainH = getTerrainHeight(this.player.position.x, this.player.position.z);
    const speed = this.keys.sprint ? 9.5 : (this.keys.crouch ? 3.5 : 6.0);

    _forwardVector(this.yaw, _vec3A);
    _rightVector(this.yaw, _vec3B);

    const moveDir = _vec3C.set(0, 0, 0);
    if (this.keys.forward) moveDir.add(_vec3A);
    if (this.keys.backward) moveDir.sub(_vec3A);
    if (this.keys.left) moveDir.sub(_vec3B);
    if (this.keys.right) moveDir.add(_vec3B);

    if (moveDir.lengthSq() > 0.001) {
      moveDir.normalize();

      const nextX = this.player.position.x + moveDir.x * speed * dt;
      const nextZ = this.player.position.z + moveDir.z * speed * dt;

      // Obstacle collision check with world buildings
      if (!this.checkObstacleCollision(nextX, nextZ, 0.4)) {
        this.player.position.x = nextX;
        this.player.position.z = nextZ;
      }

      this.player.rotation.y = this.yaw;

      // Leg running swing animation
      const runCycle = this.clock.getElapsedTime() * (this.keys.sprint ? 14 : 9);
      const legL = this.player.meshGroup.getObjectByName('LegL');
      const legR = this.player.meshGroup.getObjectByName('LegR');
      if (legL && legR) {
        legL.rotation.x = Math.sin(runCycle) * 0.65;
        legR.rotation.x = -Math.sin(runCycle) * 0.65;
      }
    } else {
      // Idle leg reset
      const legL = this.player.meshGroup.getObjectByName('LegL');
      const legR = this.player.meshGroup.getObjectByName('LegR');
      if (legL && legR) {
        legL.rotation.x = THREE.MathUtils.damp(legL.rotation.x, 0, 10, dt);
        legR.rotation.x = THREE.MathUtils.damp(legR.rotation.x, 0, 10, dt);
      }
    }

    // Jump physics & Gravity
    if (this.keys.jump && this.player.isGrounded) {
      this.player.velocity.y = 8.5;
      this.player.isGrounded = false;
    }

    if (!this.player.isGrounded) {
      this.player.velocity.y -= 22 * dt; // gravity
      this.player.position.y += this.player.velocity.y * dt;

      if (this.player.position.y <= terrainH) {
        this.player.position.y = terrainH;
        this.player.velocity.y = 0;
        this.player.isGrounded = true;
      }
    } else {
      this.player.position.y = terrainH;
    }

    this.player.meshGroup.position.copy(this.player.position);
    this.player.meshGroup.rotation.y = this.yaw;

    // Check weapon reload completion
    const curWep = this.player.weapons[this.player.currentWeaponIndex];
    if (curWep.isReloading) {
      const def = WEAPON_DEFINITIONS[curWep.type];
      if (this.clock.getElapsedTime() - curWep.reloadStartTime >= def.reloadTime) {
        const needed = def.magazineSize - curWep.currentAmmo;
        const take = Math.min(needed, curWep.reserveAmmo);
        curWep.currentAmmo += take;
        curWep.reserveAmmo -= take;
        curWep.isReloading = false;
        this.callbacks.onWeaponChange(curWep.type, curWep.currentAmmo, curWep.reserveAmmo, false);
      }
    }
  }

  /**
   * Player Shooting Mechanics with Raycasting & Headshots
   */
  private updatePlayerShooting(dt: number) {
    if (!this.keys.shoot) return;

    const wepState = this.player.weapons[this.player.currentWeaponIndex];
    const def = WEAPON_DEFINITIONS[wepState.type];
    const now = this.clock.getElapsedTime();

    if (wepState.isReloading) return;

    // Fire rate check
    if (now - wepState.lastFiredTime < def.fireRate) return;

    if (wepState.currentAmmo <= 0 && def.type !== 'KATANA') {
      this.reloadCurrentWeapon();
      return;
    }

    // Fire!
    wepState.lastFiredTime = now;
    if (def.type !== 'KATANA') {
      wepState.currentAmmo--;
      this.callbacks.onWeaponChange(def.type, wepState.currentAmmo, wepState.reserveAmmo, false);
    }

    // Play procedural sound & screen shake
    const soundType: 'AR' | 'SHOTGUN' | 'SNIPER' =
      def.type === 'SHOTGUN' ? 'SHOTGUN' : (def.type === 'SNIPER' ? 'SNIPER' : 'AR');
    sounds.playGunshot(soundType);
    this.screenShake = def.type === 'SNIPER' ? 0.35 : (def.type === 'SHOTGUN' ? 0.28 : 0.08);

    // Raycast from camera crosshair center
    const origin = this.camera.position.clone();
    _forwardVector(this.yaw, _vec3A);
    // Add vertical pitch
    _vec3A.y = Math.sin(this.pitch);
    _vec3A.normalize();

    const pellets = def.pellets || 1;
    for (let p = 0; p < pellets; p++) {
      const dir = _vec3A.clone();
      if (def.spread > 0) {
        dir.x += (Math.random() - 0.5) * def.spread;
        dir.y += (Math.random() - 0.5) * def.spread;
        dir.z += (Math.random() - 0.5) * def.spread;
        dir.normalize();
      }

      this.executeBulletShot(this.player, origin, dir, def.damage, def.range);
    }
  }

  private executeBulletShot(
    attacker: CharacterEntity,
    origin: THREE.Vector3,
    direction: THREE.Vector3,
    baseDamage: number,
    range: number
  ) {
    _raycaster.set(origin, direction);
    _raycaster.far = range;

    // Collect target meshes (bots or player)
    const targets = attacker.isPlayer
      ? this.bots.filter(b => b.isAlive).map(b => b.meshGroup)
      : (this.player && this.player.isAlive ? [this.player.meshGroup] : []);

    // Also include Gloo Walls
    const wallMeshes = this.glooWalls.map(g => g.mesh);
    const intersects = _raycaster.intersectObjects([...targets, ...wallMeshes], true);

    let hitPoint = origin.clone().addScaledVector(direction, range);
    let hitSomething = false;

    if (intersects.length > 0) {
      const hit = intersects[0];
      hitPoint = hit.point;
      hitSomething = true;

      // Check if Gloo Wall was hit
      const hitWall = this.glooWalls.find(g => g.mesh === hit.object || g.mesh.getObjectById(hit.object.id));
      if (hitWall) {
        hitWall.health -= baseDamage;
        this.spawnDamageEffect(hitPoint, baseDamage, false);
      } else {
        // Character hit! Find entity
        const hitVictim = attacker.isPlayer
          ? this.bots.find(b => b.meshGroup === hit.object || b.meshGroup.getObjectById(hit.object.id))
          : (this.player.meshGroup === hit.object || this.player.meshGroup.getObjectById(hit.object.id) ? this.player : null);

        if (hitVictim && hitVictim.isAlive) {
          const isHeadshot = hit.object.name === 'Head';
          const multiplier = isHeadshot ? 2.5 : 1.0;
          const finalDamage = Math.round(baseDamage * multiplier);

          this.applyDamage(attacker, hitVictim, finalDamage, isHeadshot, hitPoint);
        }
      }
    }

    // Spawn visual glowing tracer line
    this.spawnBulletTracer(origin, hitPoint, attacker.id, attacker.isPlayer);
  }

  private applyDamage(
    attacker: CharacterEntity,
    victim: CharacterEntity,
    damage: number,
    isHeadshot: boolean,
    hitPos: THREE.Vector3
  ) {
    // Armor absorption: absorbs 60% of damage until depleted
    if (victim.armor > 0) {
      const absorbed = Math.min(victim.armor, Math.round(damage * 0.6));
      victim.armor -= absorbed;
      victim.health -= (damage - absorbed);
    } else {
      victim.health -= damage;
    }

    if (attacker.isPlayer) {
      this.stats.damageDealt += damage;
      if (isHeadshot) this.stats.headshots++;
      sounds.playHitMarker(isHeadshot);
      this.callbacks.onHitMarker(isHeadshot);
    } else if (victim.isPlayer) {
      this.stats.damageTaken += damage;
      this.screenShake = 0.45;
    }

    // Spawn damage number
    this.spawnDamageEffect(hitPos, damage, isHeadshot);

    if (victim.isPlayer) {
      this.callbacks.onPlayerHealthChange(victim.health, victim.maxHealth, victim.armor, victim.maxArmor);
    }

    // Check Death
    if (victim.health <= 0) {
      victim.health = 0;
      victim.isAlive = false;
      attacker.kills++;

      if (attacker.isPlayer) {
        this.stats.kills = attacker.kills;
      }

      // Add to Killfeed
      const wepDef = WEAPON_DEFINITIONS[attacker.weapons[attacker.currentWeaponIndex].type];
      const killItem: KillFeedItem = {
        id: `kill_${Date.now()}_${Math.random()}`,
        killerName: attacker.name,
        victimName: victim.name,
        weaponName: wepDef.name,
        isHeadshot,
        isPlayerInvolved: attacker.isPlayer || victim.isPlayer,
        timestamp: Date.now()
      };
      this.callbacks.onKillFeedItem(killItem);

      // Defeat ragdoll / collapse & spawn Death Crate
      victim.meshGroup.rotation.x = Math.PI / 2;
      victim.meshGroup.position.y += 0.2;

      this.spawnDeathLootCrate(victim.position);

      const livingCombatants = (this.player.isAlive ? 1 : 0) + this.bots.filter(b => b.isAlive).length;
      this.callbacks.onAliveCountChange(livingCombatants, this.player.kills);

      // Check Victory or Defeat
      if (!this.player.isAlive && this.state !== 'GAMEOVER') {
        this.state = 'GAMEOVER';
        this.stats.rank = livingCombatants + 1;
        sounds.playDefeat();
        this.callbacks.onMatchEnd(false, this.stats);
      } else if (this.player.isAlive && this.bots.every(b => !b.isAlive) && this.state !== 'VICTORY') {
        this.state = 'VICTORY';
        this.stats.rank = 1;
        sounds.playBooyahFanfare();
        this.callbacks.onMatchEnd(true, this.stats);
      }
    }
  }

  private spawnDamageEffect(pos: THREE.Vector3, amount: number, isHeadshot: boolean) {
    const dmgItem: DamageNumber = {
      id: `dmg_${Date.now()}_${Math.random()}`,
      text: `${amount}`,
      position: pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 0.4, 0.4, (Math.random() - 0.5) * 0.4)),
      color: isHeadshot ? '#ef4444' : '#facc15',
      lifetime: 0,
      maxLifetime: 0.85,
      isHeadshot
    };
    this.damageNumbers.push(dmgItem);
    this.callbacks.onDamageNumber(dmgItem);
  }

  private spawnBulletTracer(start: THREE.Vector3, end: THREE.Vector3, ownerId: string, isPlayer: boolean) {
    const pts = [start, end];
    const geo = new THREE.BufferGeometry().setFromPoints(pts);
    const mat = new THREE.LineBasicMaterial({
      color: isPlayer ? 0xfacc15 : 0xf97316,
      linewidth: 2,
      transparent: true,
      opacity: 0.95
    });
    const line = new THREE.Line(geo, mat);
    this.scene.add(line);

    this.bullets.push({
      id: `bullet_${Date.now()}_${Math.random()}`,
      start: start.clone(),
      end: end.clone(),
      current: start.clone(),
      direction: _vec3A.subVectors(end, start).normalize(),
      speed: 180,
      damage: 0,
      ownerId,
      isPlayer,
      mesh: line,
      alive: true
    });
  }

  private updateBullets(dt: number) {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      const mat = (b.mesh as THREE.Line).material as THREE.LineBasicMaterial;
      mat.opacity -= dt * 7.0;

      if (mat.opacity <= 0.05) {
        this.scene.remove(b.mesh);
        b.mesh.geometry.dispose();
        mat.dispose();
        this.bullets.splice(i, 1);
      }
    }
  }

  private spawnDeathLootCrate(pos: THREE.Vector3) {
    const crate = createLootCrateModel('DEATH_CRATE');
    crate.position.copy(pos);
    this.scene.add(crate);

    this.world.lootCrates.push({
      id: `death_${Date.now()}`,
      position: pos.clone(),
      type: 'DEATH_CRATE',
      contentName: 'Medkits, Gloo Walls & Ammo',
      mesh: crate,
      pickedUp: false
    });
  }

  private checkLootPickups() {
    if (!this.player || !this.player.isAlive) return;

    this.world.lootCrates.forEach(crate => {
      if (crate.pickedUp) return;
      const d = crate.position.distanceTo(this.player.position);
      if (d < 2.5) {
        crate.pickedUp = true;
        this.scene.remove(crate.mesh);
        sounds.playLootPickup();

        // Replenish ammo, medkits, or gloo walls
        this.player.glooWallsCount = Math.min(5, this.player.glooWallsCount + 2);
        this.player.medkitsCount = Math.min(4, this.player.medkitsCount + 1);

        this.player.weapons.forEach(w => {
          w.reserveAmmo += 45;
        });

        const activeWep = this.player.weapons[this.player.currentWeaponIndex];
        this.callbacks.onWeaponChange(activeWep.type, activeWep.currentAmmo, activeWep.reserveAmmo, activeWep.isReloading);
        this.callbacks.onGlooCountChange(this.player.glooWallsCount);
        this.callbacks.onMedkitCountChange(this.player.medkitsCount);
      }
    });
  }

  /**
   * AI Tactical Bot Logic (Parachute Drop -> Patrol -> Combat -> Safe Zone)
   */
  private updateBots(dt: number) {
    this.bots.forEach(bot => {
      if (!bot.isAlive) return;

      if (bot.isParachuting) {
        this.updateParachuting(bot, dt);
        return;
      }

      // Ground AI updates
      bot.aiTimer = (bot.aiTimer || 0) - dt;
      bot.shootCooldown = (bot.shootCooldown || 0) - dt;

      // Distance to player
      const distToPlayer = bot.position.distanceTo(this.player.position);

      // 1. Target acquisition (Player or other bots)
      if (distToPlayer < 45 && this.player.isAlive) {
        bot.attackTarget = this.player;
        bot.aiState = 'COMBAT';
      } else {
        // Check storm flee
        const distFromCenter = Math.sqrt(bot.position.x * bot.position.x + bot.position.z * bot.position.z);
        if (distFromCenter > this.safeZone.currentRadius - 10) {
          bot.aiState = 'FLEE_STORM';
          bot.targetPos = new THREE.Vector3(this.safeZone.targetCenter.x, 0, this.safeZone.targetCenter.y);
        } else if (bot.aiTimer <= 0) {
          bot.aiState = 'PATROL';
          bot.aiTimer = 4 + Math.random() * 5;
          const wanderAngle = Math.random() * Math.PI * 2;
          const r = 15 + Math.random() * 25;
          bot.targetPos = new THREE.Vector3(
            bot.position.x + Math.cos(wanderAngle) * r,
            0,
            bot.position.z + Math.sin(wanderAngle) * r
          );
        }
      }

      // 2. State Actions
      if (bot.aiState === 'COMBAT' && bot.attackTarget && bot.attackTarget.isAlive) {
        // Face target
        const targetPos = bot.attackTarget.position;
        const toTarget = _vec3A.subVectors(targetPos, bot.position);
        toTarget.y = 0;
        const targetDist = toTarget.length();

        if (targetDist > 0.1) {
          toTarget.normalize();
          bot.rotation.y = Math.atan2(toTarget.x, toTarget.z);
          bot.meshGroup.rotation.y = bot.rotation.y;
        }

        // Tactical strafe movement
        if (targetDist > 14) {
          // Approach
          bot.position.addScaledVector(toTarget, 4.5 * dt);
        } else if (targetDist < 6) {
          // Back up
          bot.position.addScaledVector(toTarget, -3.5 * dt);
        }

        // Fire burst
        if (bot.shootCooldown <= 0) {
          bot.shootCooldown = 0.35 + Math.random() * 0.45;
          const origin = bot.position.clone().add(new THREE.Vector3(0, 1.4, 0));
          const aimDir = _vec3A.subVectors(targetPos.clone().add(new THREE.Vector3(0, 1.3, 0)), origin).normalize();
          // Bot inaccuracy
          aimDir.x += (Math.random() - 0.5) * 0.12;
          aimDir.y += (Math.random() - 0.5) * 0.08;
          aimDir.z += (Math.random() - 0.5) * 0.12;
          aimDir.normalize();

          sounds.playGunshot('AR');
          this.executeBulletShot(bot, origin, aimDir, 16, 80);
        }
      } else if (bot.targetPos) {
        // Move towards waypoint
        const toWay = _vec3A.subVectors(bot.targetPos, bot.position);
        toWay.y = 0;
        if (toWay.lengthSq() > 2) {
          toWay.normalize();
          bot.position.addScaledVector(toWay, 4.8 * dt);
          bot.rotation.y = Math.atan2(toWay.x, toWay.z);
          bot.meshGroup.rotation.y = bot.rotation.y;
        }
      }

      // Ground snapping
      const groundH = getTerrainHeight(bot.position.x, bot.position.z);
      bot.position.y = groundH;
      bot.meshGroup.position.copy(bot.position);
    });
  }

  /**
   * Safe Zone Electric Storm Updates
   */
  private updateSafeZone(dt: number) {
    if (this.safeZone.isShrinking) {
      // Interpolate radius towards target
      const shrinkSpeed = (this.safeZone.currentRadius - this.safeZone.targetRadius) / 20;
      this.safeZone.currentRadius -= Math.max(shrinkSpeed, 2.5) * dt;

      if (this.safeZone.currentRadius <= this.safeZone.targetRadius) {
        this.safeZone.currentRadius = this.safeZone.targetRadius;
        this.safeZone.isShrinking = false;
        this.safeZone.phase++;
        this.safeZone.targetRadius = Math.max(15, this.safeZone.currentRadius * 0.55);
        this.safeZone.timeUntilNextShrink = 45;
      }
    } else {
      this.safeZone.timeUntilNextShrink -= dt;
      if (this.safeZone.timeUntilNextShrink <= 0) {
        this.safeZone.isShrinking = true;
        sounds.playStormAlert();
      }
    }

    // Update 3D Safe Zone mesh cylinder scale
    if (this.world.safeZoneMesh) {
      const scale = this.safeZone.currentRadius / ISLAND_RADIUS;
      this.world.safeZoneMesh.scale.set(scale, 1, scale);
      this.world.safeZoneRing.scale.set(scale, 1, scale);
    }

    // Damage players/bots outside current radius
    if (this.player && this.player.isAlive && !this.player.isParachuting) {
      const pDist = Math.sqrt(this.player.position.x * this.player.position.x + this.player.position.z * this.player.position.z);
      if (pDist > this.safeZone.currentRadius) {
        this.player.health -= this.safeZone.damagePerSec * dt;
        this.callbacks.onPlayerHealthChange(this.player.health, this.player.maxHealth, this.player.armor, this.player.maxArmor);
        if (this.player.health <= 0) {
          this.applyDamage(this.player, this.player, 10, false, this.player.position);
        }
      }
    }

    this.callbacks.onSafeZoneChange(this.safeZone);
  }

  private updateGlooWalls(dt: number) {
    for (let i = this.glooWalls.length - 1; i >= 0; i--) {
      const wall = this.glooWalls[i];
      if (wall.health <= 0 || (this.clock.getElapsedTime() - wall.timestamp > 45)) {
        this.scene.remove(wall.mesh);
        this.glooWalls.splice(i, 1);
      }
    }
  }

  private updateCamera(dt: number) {
    if (!this.player) return;

    // Smooth Third-Person Shoulder View
    const targetY = this.player.position.y + this.cameraHeight;
    const isAiming = this.keys.aim;
    const currentDist = isAiming ? 2.0 : (this.player.isParachuting ? 5.8 : this.cameraDistance);

    // Camera offset behind player based on yaw & pitch
    _camOffset.x = Math.sin(this.yaw) * Math.cos(this.pitch) * currentDist;
    _camOffset.y = Math.sin(this.pitch) * currentDist;
    _camOffset.z = Math.cos(this.yaw) * Math.cos(this.pitch) * currentDist;

    // Right-shoulder offset for tactical shooting
    _rightVector(this.yaw, _vec3A);
    const shoulderOffset = isAiming ? 0.6 : 0.45;
    _camOffset.addScaledVector(_vec3A, shoulderOffset);

    const desiredCamPos = this.player.position.clone();
    desiredCamPos.y = targetY;
    desiredCamPos.add(_camOffset);

    // Apply screen shake
    if (this.screenShake > 0.001) {
      desiredCamPos.x += (Math.random() - 0.5) * this.screenShake;
      desiredCamPos.y += (Math.random() - 0.5) * this.screenShake;
      this.screenShake = THREE.MathUtils.damp(this.screenShake, 0, 10, dt);
    }

    this.camera.position.lerp(desiredCamPos, 0.28);

    // Look at player chest/crosshair point
    const lookTarget = this.player.position.clone();
    lookTarget.y = targetY + Math.sin(this.pitch) * 1.5;
    lookTarget.addScaledVector(_vec3A, shoulderOffset * 0.5);
    _forwardVector(this.yaw, _vec3B);
    lookTarget.addScaledVector(_vec3B, 15);

    this.camera.lookAt(lookTarget);
  }

  private checkObstacleCollision(x: number, z: number, radius: number): boolean {
    const pBox = new THREE.Box3();
    pBox.min.set(x - radius, 0, z - radius);
    pBox.max.set(x + radius, 4, z + radius);

    for (const c of this.world.colliders) {
      if (pBox.intersectsBox(c)) return true;
    }
    return false;
  }

  private syncMinimap() {
    if (!this.player) return;
    const enemies = this.bots.filter(b => b.isAlive).map(b => ({
      pos: b.position.clone(),
      firing: (b.shootCooldown || 0) > 0.3
    }));
    this.callbacks.onMinimapUpdate(this.player.position, this.yaw, enemies);
  }

  private syncAllHUD() {
    if (!this.player) return;
    this.callbacks.onPlayerHealthChange(this.player.health, this.player.maxHealth, this.player.armor, this.player.maxArmor);
    const wep = this.player.weapons[this.player.currentWeaponIndex];
    this.callbacks.onWeaponChange(wep.type, wep.currentAmmo, wep.reserveAmmo, wep.isReloading);
    this.callbacks.onGlooCountChange(this.player.glooWallsCount);
    this.callbacks.onMedkitCountChange(this.player.medkitsCount);
    this.callbacks.onAliveCountChange(this.bots.filter(b => b.isAlive).length + 1, this.player.kills);
  }

  private render() {
    this.renderer.render(this.scene, this.camera);
  }

  public dispose() {
    this.isDisposed = true;
    cancelAnimationFrame(this.frameId);
    sounds.stopWind();
    this.renderer.dispose();
  }
}

// Math helpers
function _forwardVector(yaw: number, out: THREE.Vector3): THREE.Vector3 {
  out.set(-Math.sin(yaw), 0, -Math.cos(yaw)).normalize();
  return out;
}

function _rightVector(yaw: number, out: THREE.Vector3): THREE.Vector3 {
  out.set(-Math.cos(yaw), 0, Math.sin(yaw)).normalize();
  return out;
}
