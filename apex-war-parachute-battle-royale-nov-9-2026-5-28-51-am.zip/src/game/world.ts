/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import {
  createTreeModel,
  createRockModel,
  createWatchtowerModel,
  createBunkerBuildingModel,
  createLootCrateModel
} from './models';
import { LootCrate, SafeZone } from './types';

// Map boundary & dimensions
export const MAP_SIZE = 380;
export const ISLAND_RADIUS = 150;

/**
 * Procedural height function for the Battle Royale island
 */
export function getTerrainHeight(x: number, z: number): number {
  const dist = Math.sqrt(x * x + z * z);

  // Sea level drop beyond island radius
  if (dist > ISLAND_RADIUS + 30) {
    return -4.0;
  }

  // Gentle hills using combined sine/cosine frequencies
  const baseH = Math.sin(x * 0.02) * Math.cos(z * 0.02) * 4.5 +
                Math.sin(x * 0.045 + 1.2) * Math.sin(z * 0.038) * 2.5;

  // Flatten central landing compound for smoother combat
  const centerDist = Math.sqrt(x * x + z * z);
  let flatWeight = 1.0;
  if (centerDist < 45) {
    flatWeight = Math.max(0, (centerDist - 15) / 30);
  }

  let h = baseH * flatWeight + 2.5;

  // Shore slope down to water level at perimeter
  if (dist > ISLAND_RADIUS - 20) {
    const t = (dist - (ISLAND_RADIUS - 20)) / 50;
    h = THREE.MathUtils.lerp(h, -3.5, Math.min(1.0, t));
  }

  return h;
}

export interface WorldBuildResult {
  terrainMesh: THREE.Mesh;
  waterMesh: THREE.Mesh;
  safeZoneMesh: THREE.Mesh;
  safeZoneRing: THREE.Line;
  colliders: THREE.Box3[];
  lootCrates: LootCrate[];
  spawnPoints: THREE.Vector3[];
}

export function buildWorld(scene: THREE.Scene): WorldBuildResult {
  const colliders: THREE.Box3[] = [];
  const lootCrates: LootCrate[] = [];
  const spawnPoints: THREE.Vector3[] = [];

  // 1. Procedural Island Terrain Geometry
  const segs = 120;
  const terrainGeo = new THREE.PlaneGeometry(MAP_SIZE, MAP_SIZE, segs, segs);
  terrainGeo.rotateX(-Math.PI / 2);

  const posAttr = terrainGeo.attributes.position;
  const colors: number[] = [];
  const cGrass = new THREE.Color(0x3f6212); // military olive green
  const cHighland = new THREE.Color(0x4d7c0f);
  const cSand = new THREE.Color(0xd4b483);
  const cRock = new THREE.Color(0x64748b);
  const tempC = new THREE.Color();

  for (let i = 0; i < posAttr.count; i++) {
    const x = posAttr.getX(i);
    const z = posAttr.getZ(i);
    const y = getTerrainHeight(x, z);
    posAttr.setY(i, y);

    const dist = Math.sqrt(x * x + z * z);
    if (y < 0.2 || dist > ISLAND_RADIUS - 15) {
      tempC.copy(cSand);
    } else if (y > 6.0) {
      tempC.copy(cRock);
    } else if (y > 3.0) {
      tempC.copy(cHighland);
    } else {
      tempC.copy(cGrass);
    }
    // Subtle noise tint variation
    const tint = (Math.sin(x * 0.3) * Math.cos(z * 0.3)) * 0.08;
    tempC.offsetHSL(0, 0, tint);
    colors.push(tempC.r, tempC.g, tempC.b);
  }

  terrainGeo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  terrainGeo.computeVertexNormals();

  const terrainMat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: 0.88,
    metalness: 0.08,
    flatShading: true
  });
  const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
  terrainMesh.receiveShadow = true;
  terrainMesh.name = 'Terrain';
  scene.add(terrainMesh);

  // 2. Stylized Ocean Water
  const waterGeo = new THREE.PlaneGeometry(MAP_SIZE * 2, MAP_SIZE * 2);
  waterGeo.rotateX(-Math.PI / 2);
  const waterMat = new THREE.MeshStandardMaterial({
    color: 0x0284c7,
    roughness: 0.15,
    metalness: 0.4,
    transparent: true,
    opacity: 0.82
  });
  const waterMesh = new THREE.Mesh(waterGeo, waterMat);
  waterMesh.position.y = -0.6;
  waterMesh.receiveShadow = true;
  waterMesh.name = 'Ocean';
  scene.add(waterMesh);

  // 3. Central Military Forward Operating Base (Compounds & Bunkers)
  const compoundPositions = [
    { x: -25, z: -20, w: 12, h: 5, d: 9, rot: 0.2 },
    { x: 30, z: -15, w: 14, h: 5.5, d: 10, rot: -0.3 },
    { x: -15, z: 35, w: 10, h: 4.8, d: 8, rot: 1.1 },
    { x: 35, z: 30, w: 12, h: 5, d: 9, rot: 2.2 },
    // Outpost stations
    { x: -65, z: -45, w: 8, h: 4, d: 7, rot: 0.5 },
    { x: 60, z: -55, w: 8, h: 4, d: 7, rot: -0.8 },
    { x: -55, z: 65, w: 9, h: 4.2, d: 8, rot: 1.4 },
    { x: 70, z: 50, w: 9, h: 4.2, d: 8, rot: -1.2 }
  ];

  compoundPositions.forEach((b) => {
    const y = getTerrainHeight(b.x, b.z);
    const bunker = createBunkerBuildingModel(b.w, b.h, b.d);
    bunker.position.set(b.x, y, b.z);
    bunker.rotation.y = b.rot;
    scene.add(bunker);

    // Add bounding box collider
    const box = new THREE.Box3();
    box.setFromObject(bunker);
    // Expand slightly for collision buffer
    box.expandByScalar(0.2);
    colliders.push(box);

    // Spawn tactical loot crate inside or near compound
    const loot = createLootCrateModel('CRATE');
    const lx = b.x + Math.sin(b.rot) * (b.w * 0.4);
    const lz = b.z + Math.cos(b.rot) * (b.d * 0.4);
    const ly = getTerrainHeight(lx, lz);
    loot.position.set(lx, ly, lz);
    scene.add(loot);

    lootCrates.push({
      id: `loot_${lootCrates.length}`,
      position: new THREE.Vector3(lx, ly, lz),
      type: 'WEAPON',
      contentName: 'Assault Ammo & Medkit',
      mesh: loot,
      pickedUp: false
    });
  });

  // 4. Watchtowers at strategic ridge vantage points
  const towerPositions = [
    { x: -35, z: 5 },
    { x: 20, z: -40 },
    { x: -45, z: -35 },
    { x: 50, z: 25 },
    { x: 0, z: 55 }
  ];

  towerPositions.forEach((tp) => {
    const ty = getTerrainHeight(tp.x, tp.z);
    const tower = createWatchtowerModel();
    tower.position.set(tp.x, ty, tp.z);
    scene.add(tower);

    const box = new THREE.Box3();
    box.setFromObject(tower);
    colliders.push(box);

    // Loot on top or base of watchtower
    const loot = createLootCrateModel('CRATE');
    loot.position.set(tp.x + 1.2, ty, tp.z + 1.2);
    scene.add(loot);
    lootCrates.push({
      id: `loot_${lootCrates.length}`,
      position: new THREE.Vector3(tp.x + 1.2, ty, tp.z + 1.2),
      type: 'AMMO',
      contentName: 'Sniper & Heavy Ammo',
      mesh: loot,
      pickedUp: false
    });
  });

  // 5. High-Value Airdrops scattered across the island
  const airdropPositions = [
    { x: 5, z: -10 },
    { x: -30, z: -60 },
    { x: 45, z: -20 },
    { x: 20, z: 60 }
  ];

  airdropPositions.forEach((ap, i) => {
    const ay = getTerrainHeight(ap.x, ap.z);
    const airdrop = createLootCrateModel('AIRDROP');
    airdrop.position.set(ap.x, ay, ap.z);
    scene.add(airdrop);

    lootCrates.push({
      id: `airdrop_${i}`,
      position: new THREE.Vector3(ap.x, ay, ap.z),
      type: 'AIRDROP',
      contentName: 'Lv.3 Armor & AWM Sniper & Gloo Walls',
      mesh: airdrop,
      pickedUp: false
    });
  });

  // 6. Foliage & Rocks (Trees and polyhedral boulders)
  for (let i = 0; i < 75; i++) {
    const angle = Math.random() * Math.PI * 2;
    const r = 25 + Math.random() * (ISLAND_RADIUS - 35);
    const tx = Math.cos(angle) * r;
    const tz = Math.sin(angle) * r;
    const ty = getTerrainHeight(tx, tz);

    if (ty > 0.8) {
      const treeScale = 0.85 + Math.random() * 0.45;
      const tree = createTreeModel(treeScale);
      tree.position.set(tx, ty, tz);
      tree.rotation.y = Math.random() * Math.PI * 2;
      scene.add(tree);

      const tBox = new THREE.Box3();
      tBox.min.set(tx - 0.4, ty, tz - 0.4);
      tBox.max.set(tx + 0.4, ty + 4.0, tz + 0.4);
      colliders.push(tBox);
    }
  }

  for (let i = 0; i < 45; i++) {
    const angle = Math.random() * Math.PI * 2;
    const r = 15 + Math.random() * (ISLAND_RADIUS - 30);
    const rx = Math.cos(angle) * r;
    const rz = Math.sin(angle) * r;
    const ry = getTerrainHeight(rx, rz);

    if (ry > 0.5) {
      const rScale = 0.8 + Math.random() * 0.8;
      const rock = createRockModel(rScale);
      rock.position.set(rx, ry, rz);
      rock.rotation.set(Math.random() * 0.3, Math.random() * Math.PI, 0);
      scene.add(rock);

      const rBox = new THREE.Box3();
      rBox.min.set(rx - 0.8 * rScale, ry, rz - 0.8 * rScale);
      rBox.max.set(rx + 0.8 * rScale, ry + 1.2 * rScale, rz + 0.8 * rScale);
      colliders.push(rBox);
    }
  }

  // 7. Spawn Points for Player and Enemy Bots (distributed across the drop area)
  // Player spawns dead center at altitude 160m
  spawnPoints.push(new THREE.Vector3(0, 160, 0));

  // 17 Bot drop points spread across island skies
  for (let i = 0; i < 17; i++) {
    const angle = (i / 17) * Math.PI * 2 + (Math.random() - 0.5) * 0.3;
    const r = 20 + Math.random() * 65;
    const bx = Math.cos(angle) * r;
    const bz = Math.sin(angle) * r;
    spawnPoints.push(new THREE.Vector3(bx, 150 + Math.random() * 20, bz));
  }

  // 8. Safe Zone Blue Electric Storm Wall (Cylinder)
  const zoneGeo = new THREE.CylinderGeometry(ISLAND_RADIUS, ISLAND_RADIUS, 180, 48, 1, true);
  const zoneMat = new THREE.MeshBasicMaterial({
    color: 0x00a8ff,
    transparent: true,
    opacity: 0.28,
    side: THREE.DoubleSide,
    depthWrite: false
  });
  const safeZoneMesh = new THREE.Mesh(zoneGeo, zoneMat);
  safeZoneMesh.position.y = 80;
  scene.add(safeZoneMesh);

  // Safe Zone top/ground pulse ring
  const ringPts: THREE.Vector3[] = [];
  for (let i = 0; i <= 64; i++) {
    const a = (i / 64) * Math.PI * 2;
    ringPts.push(new THREE.Vector3(Math.cos(a) * ISLAND_RADIUS, 1.2, Math.sin(a) * ISLAND_RADIUS));
  }
  const ringGeo = new THREE.BufferGeometry().setFromPoints(ringPts);
  const ringMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, linewidth: 2 });
  const safeZoneRing = new THREE.Line(ringGeo, ringMat);
  scene.add(safeZoneRing);

  return {
    terrainMesh,
    waterMesh,
    safeZoneMesh,
    safeZoneRing,
    colliders,
    lootCrates,
    spawnPoints
  };
}
