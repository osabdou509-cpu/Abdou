/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Procedural Web Audio API sound generator for Battle Royale war game
class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private isMuted: boolean = false;
  private windNode: AudioBufferSourceNode | null = null;
  private windGain: GainNode | null = null;
  private windFilter: BiquadFilterNode | null = null;

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.isMuted ? 0 : 0.85;
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.masterGain) {
      this.masterGain.gain.value = muted ? 0 : 0.85;
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    this.setMuted(!this.isMuted);
    return this.isMuted;
  }

  // Continuous wind sound for parachuting/freefall
  public startWind(intensity: number = 0.5) {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.windNode) return;

    try {
      const bufferSize = this.ctx.sampleRate * 2;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        // Pink-ish noise filter
        lastOut = (lastOut * 0.95) + (white * 0.05);
        data[i] = lastOut;
      }

      this.windNode = this.ctx.createBufferSource();
      this.windNode.buffer = buffer;
      this.windNode.loop = true;

      this.windFilter = this.ctx.createBiquadFilter();
      this.windFilter.type = 'lowpass';
      this.windFilter.frequency.value = 400 + intensity * 800;

      this.windGain = this.ctx.createGain();
      this.windGain.gain.value = Math.min(intensity * 0.35, 0.4);

      this.windNode.connect(this.windFilter);
      this.windFilter.connect(this.windGain);
      this.windGain.connect(this.masterGain);

      this.windNode.start();
    } catch {
      // Audio context might be restricted before user gesture
    }
  }

  public updateWind(speedNorm: number) {
    if (this.windFilter && this.windGain && this.ctx) {
      const t = this.ctx.currentTime;
      this.windFilter.frequency.cancelScheduledValues(t);
      this.windFilter.frequency.setTargetAtTime(300 + speedNorm * 1100, t, 0.1);
      this.windGain.gain.cancelScheduledValues(t);
      this.windGain.gain.setTargetAtTime(Math.min(speedNorm * 0.45, 0.5), t, 0.1);
    }
  }

  public stopWind() {
    if (this.windNode) {
      try {
        this.windNode.stop();
        this.windNode.disconnect();
      } catch {}
      this.windNode = null;
      this.windGain = null;
      this.windFilter = null;
    }
  }

  // Parachute deploy snap & flutter
  public playParachuteDeploy() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(140, t);
    osc.frequency.exponentialRampToValueAtTime(45, t + 0.35);

    gain.gain.setValueAtTime(0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.4);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.4);

    // Add snap burst
    this.playNoiseBurst(0.25, 600, 0.3);
  }

  // Touchdown thud
  public playLandThud() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(90, t);
    osc.frequency.exponentialRampToValueAtTime(30, t + 0.25);

    gain.gain.setValueAtTime(0.5, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.3);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.3);
  }

  // Assault Rifle Gunshot (SCAR / M4A1 style)
  public playGunshot(type: 'AR' | 'SHOTGUN' | 'SNIPER') {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;

    if (type === 'AR') {
      // AR punch
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(260, t);
      osc.frequency.exponentialRampToValueAtTime(60, t + 0.08);

      gain.gain.setValueAtTime(0.4, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.1);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.1);

      this.playNoiseBurst(0.09, 1800, 0.35);
    } else if (type === 'SHOTGUN') {
      // Heavy shotgun blast
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(150, t);
      osc.frequency.exponentialRampToValueAtTime(35, t + 0.22);

      gain.gain.setValueAtTime(0.65, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.25);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.25);

      this.playNoiseBurst(0.22, 1200, 0.6);
    } else if (type === 'SNIPER') {
      // High-power AWM crack
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(420, t);
      osc.frequency.exponentialRampToValueAtTime(40, t + 0.4);

      gain.gain.setValueAtTime(0.7, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.45);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.45);

      this.playNoiseBurst(0.35, 2400, 0.7);
    }
  }

  // Gloo Wall deploy (magical ice/barrier crystal sound)
  public playGlooWallDeploy() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(220, t);
    osc.frequency.linearRampToValueAtTime(680, t + 0.15);
    osc.frequency.exponentialRampToValueAtTime(320, t + 0.35);

    gain.gain.setValueAtTime(0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.35);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.35);

    this.playNoiseBurst(0.18, 2000, 0.25);
  }

  // Katana swing
  public playKatanaSlash() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    this.playNoiseBurst(0.12, 1400, 0.35);
  }

  // Hit sound marker (crisp metallic clink)
  public playHitMarker(isHeadshot: boolean = false) {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = isHeadshot ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(isHeadshot ? 1400 : 880, t);
    osc.frequency.exponentialRampToValueAtTime(isHeadshot ? 800 : 440, t + 0.08);

    gain.gain.setValueAtTime(isHeadshot ? 0.6 : 0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.09);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.09);
  }

  // Loot pickup chime
  public playLootPickup() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;

    [523.25, 659.25, 783.99].forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + idx * 0.05);

      gain.gain.setValueAtTime(0.25, t + idx * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.01, t + idx * 0.05 + 0.12);

      osc.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(t + idx * 0.05);
      osc.stop(t + idx * 0.05 + 0.15);
    });
  }

  // Medkit heal sound
  public playMedkitUse() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;
    [392, 523.25, 659.25, 1046.5].forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t + idx * 0.07);
      gain.gain.setValueAtTime(0.22, t + idx * 0.07);
      gain.gain.exponentialRampToValueAtTime(0.01, t + idx * 0.07 + 0.2);
      osc.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(t + idx * 0.07);
      osc.stop(t + idx * 0.07 + 0.22);
    });
  }

  // Reload click-clack
  public playReload() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;

    const click = (delay: number, pitch: number) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(pitch, t + delay);
      gain.gain.setValueAtTime(0.18, t + delay);
      gain.gain.exponentialRampToValueAtTime(0.01, t + delay + 0.05);
      osc.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(t + delay);
      osc.stop(t + delay + 0.06);
    };

    click(0.0, 700);
    click(0.2, 550);
    click(0.5, 900);
  }

  // Electric storm zone alert
  public playStormAlert() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(440, t);
    osc.frequency.linearRampToValueAtTime(330, t + 0.3);
    osc.frequency.linearRampToValueAtTime(440, t + 0.6);

    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.7);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.7);
  }

  // Free Fire "BOOYAH!" Victory Fanfare
  public playBooyahFanfare() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;

    // Victory triumphant brass notes: C4, E4, G4, C5 (held)
    const notes = [
      { f: 261.63, d: 0.15, wait: 0 },
      { f: 329.63, d: 0.15, wait: 0.15 },
      { f: 392.0,  d: 0.15, wait: 0.30 },
      { f: 523.25, d: 0.8,  wait: 0.45 },
      { f: 659.25, d: 0.9,  wait: 0.65 },
      { f: 783.99, d: 1.4,  wait: 0.85 }
    ];

    notes.forEach((note) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(note.f, t + note.wait);

      gain.gain.setValueAtTime(0.35, t + note.wait);
      gain.gain.exponentialRampToValueAtTime(0.01, t + note.wait + note.d);

      osc.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(t + note.wait);
      osc.stop(t + note.wait + note.d);
    });
  }

  // Defeat / Game Over stinger
  public playDefeat() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;

    const notes = [311.13, 293.66, 277.18, 261.63];
    notes.forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t + idx * 0.2);

      gain.gain.setValueAtTime(0.3, t + idx * 0.2);
      gain.gain.exponentialRampToValueAtTime(0.01, t + idx * 0.2 + 0.35);

      osc.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(t + idx * 0.2);
      osc.stop(t + idx * 0.2 + 0.4);
    });
  }

  private playNoiseBurst(duration: number, cutoff: number, volume: number) {
    if (!this.ctx || !this.masterGain) return;
    try {
      const bufferSize = Math.floor(this.ctx.sampleRate * duration);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = cutoff;

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(volume, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + duration);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      noise.start();
    } catch {}
  }
}

export const sounds = new SoundEngine();
