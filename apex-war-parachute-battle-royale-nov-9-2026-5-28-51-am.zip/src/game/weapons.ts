/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WeaponDef, WeaponType } from './types';

export const WEAPON_DEFINITIONS: Record<WeaponType, WeaponDef> = {
  AR: {
    type: 'AR',
    name: 'SCAR-L Assault Rifle',
    nameAr: 'بندقية هجومية SCAR-L',
    damage: 32,
    fireRate: 0.11, // ~550 RPM
    magazineSize: 30,
    reloadTime: 2.0,
    range: 120,
    spread: 0.035,
    automatic: true,
    ammoType: '5.56mm'
  },
  SHOTGUN: {
    type: 'SHOTGUN',
    name: 'M1887 Dual Shotgun',
    nameAr: 'شوزن M1887 المزدوج',
    damage: 26, // per pellet
    pellets: 8, // total potential ~208 dmg
    fireRate: 0.55,
    magazineSize: 2,
    reloadTime: 2.2,
    range: 35,
    spread: 0.095,
    automatic: false,
    ammoType: '12-Gauge'
  },
  SNIPER: {
    type: 'SNIPER',
    name: 'AWM Heavy Sniper',
    nameAr: 'قناصة AWM الثقيلة',
    damage: 150, // 300 on headshot
    fireRate: 1.4,
    magazineSize: 5,
    reloadTime: 3.0,
    range: 300,
    spread: 0.005,
    automatic: false,
    ammoType: '.300 Magnum'
  },
  KATANA: {
    type: 'KATANA',
    name: 'Katana Blade',
    nameAr: 'سيف الكاتانا',
    damage: 65,
    fireRate: 0.45,
    magazineSize: 999,
    reloadTime: 0,
    range: 4.0,
    spread: 0.1,
    automatic: false,
    ammoType: 'Melee'
  },
  GLOO_WALL: {
    type: 'GLOO_WALL',
    name: 'Gloo Wall Granade',
    nameAr: 'قنبلة جدار الغلو',
    damage: 0,
    fireRate: 0.8,
    magazineSize: 1,
    reloadTime: 0.5,
    range: 12,
    spread: 0,
    automatic: false,
    ammoType: 'Defensive'
  }
};
