/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect, useState, useCallback } from 'react';
import * as THREE from 'three';
import { GameEngine } from './game/engine';
import { GameState, WeaponType, SafeZone, KillFeedItem, MatchStats } from './game/types';
import { sounds } from './game/audio';
import { TitleScreen } from './components/TitleScreen';
import { GameHUD } from './components/GameHUD';
import { TouchControls } from './components/TouchControls';
import { GameOverModal } from './components/GameOverModal';

export default function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Game UI States
  const [gameState, setGameState] = useState<GameState>('TITLE');
  const [isArabic, setIsArabic] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Player stats
  const [health, setHealth] = useState(200);
  const [maxHealth, setMaxHealth] = useState(200);
  const [armor, setArmor] = useState(100);
  const [maxArmor, setMaxArmor] = useState(100);
  const [aliveCount, setAliveCount] = useState(18);
  const [kills, setKills] = useState(0);

  // Weapon & items
  const [currentWeapon, setCurrentWeapon] = useState<WeaponType>('AR');
  const [currentAmmo, setCurrentAmmo] = useState(30);
  const [reserveAmmo, setReserveAmmo] = useState(120);
  const [isReloading, setIsReloading] = useState(false);
  const [glooCount, setGlooCount] = useState(3);
  const [medkitCount, setMedkitCount] = useState(2);

  // Parachute metrics
  const [altitude, setAltitude] = useState(160);
  const [speed, setSpeed] = useState(20);
  const [isParachuting, setIsParachuting] = useState(false);

  // Safe Zone & Combat alerts
  const [safeZone, setSafeZone] = useState<SafeZone | null>(null);
  const [killFeed, setKillFeed] = useState<KillFeedItem[]>([]);
  const [hitMarkerActive, setHitMarkerActive] = useState(false);
  const [isHeadshotHit, setIsHeadshotHit] = useState(false);
  const [matchResult, setMatchResult] = useState<{ victory: boolean; stats: MatchStats } | null>(null);

  // Minimap coordinates
  const [playerPos, setPlayerPos] = useState<THREE.Vector3>(new THREE.Vector3(0, 0, 0));
  const [playerYaw, setPlayerYaw] = useState<number>(0);
  const [enemies, setEnemies] = useState<{ pos: THREE.Vector3; firing: boolean }[]>([]);

  // Mobile / Touch detection
  const [isTouchDevice, setIsTouchDevice] = useState(false);

  useEffect(() => {
    setIsTouchDevice('ontouchstart' in window || navigator.maxTouchPoints > 0);
  }, []);

  // Initialize Three.js Engine once on mount
  useEffect(() => {
    if (!mountRef.current || engineRef.current) return;

    const engine = new GameEngine(mountRef.current, {
      onStateChange: (newState) => {
        setGameState(newState);
        if (newState === 'PARACHUTING') {
          setIsParachuting(true);
        } else if (newState === 'PLAYING') {
          setIsParachuting(false);
        }
      },
      onPlayerHealthChange: (hp, maxHp, ap, maxAp) => {
        setHealth(hp);
        setMaxHealth(maxHp);
        setArmor(ap);
        setMaxArmor(maxAp);
      },
      onWeaponChange: (wep, ammo, reserve, reloading) => {
        setCurrentWeapon(wep);
        setCurrentAmmo(ammo);
        setReserveAmmo(reserve);
        setIsReloading(reloading);
      },
      onGlooCountChange: (count) => setGlooCount(count),
      onMedkitCountChange: (count) => setMedkitCount(count),
      onAliveCountChange: (alive, k) => {
        setAliveCount(alive);
        setKills(k);
      },
      onAltitudeChange: (alt, spd, parachuting) => {
        setAltitude(alt);
        setSpeed(spd);
        setIsParachuting(parachuting);
      },
      onSafeZoneChange: (zone) => setSafeZone({ ...zone }),
      onKillFeedItem: (item) => {
        setKillFeed((prev) => [...prev.slice(-6), item]);
      },
      onDamageNumber: () => {},
      onHitMarker: (headshot) => {
        setHitMarkerActive(true);
        setIsHeadshotHit(headshot);
        setTimeout(() => setHitMarkerActive(false), 160);
      },
      onMatchEnd: (victory, stats) => {
        setMatchResult({ victory, stats });
      },
      onMinimapUpdate: (pos, yaw, enemyList) => {
        setPlayerPos(pos.clone());
        setPlayerYaw(yaw);
        setEnemies(enemyList);
      }
    });

    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  // Handlers
  const handleStartGame = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.startMatch();
      setMatchResult(null);
      engineRef.current.requestPointerLock();
    }
  }, []);

  const handleRestart = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.startMatch();
      setMatchResult(null);
      engineRef.current.requestPointerLock();
    }
  }, []);

  const handleToggleLang = useCallback(() => {
    setIsArabic((prev) => !prev);
  }, []);

  const handleToggleMute = useCallback(() => {
    const muted = sounds.toggleMute();
    setIsMuted(muted);
  }, []);

  const handleSwitchWeapon = useCallback((idx: number) => {
    if (engineRef.current) engineRef.current.switchWeapon(idx);
  }, []);

  const handleDeployGloo = useCallback(() => {
    if (engineRef.current) engineRef.current.deployGlooWall();
  }, []);

  const handleUseMedkit = useCallback(() => {
    if (engineRef.current) engineRef.current.useMedkit();
  }, []);

  const handleReload = useCallback(() => {
    if (engineRef.current) engineRef.current.reloadCurrentWeapon();
  }, []);

  // Touch handlers
  const handleTouchMove = useCallback((dir: { x: number; y: number }) => {
    if (!engineRef.current) return;
    engineRef.current.keys.forward = dir.y < -0.2;
    engineRef.current.keys.backward = dir.y > 0.2;
    engineRef.current.keys.left = dir.x < -0.2;
    engineRef.current.keys.right = dir.x > 0.2;
  }, []);

  const handleTouchShootStart = useCallback(() => {
    if (engineRef.current) engineRef.current.keys.shoot = true;
  }, []);

  const handleTouchShootEnd = useCallback(() => {
    if (engineRef.current) engineRef.current.keys.shoot = false;
  }, []);

  const handleTouchJump = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.keys.jump = true;
      setTimeout(() => {
        if (engineRef.current) engineRef.current.keys.jump = false;
      }, 150);
    }
  }, []);

  const handleTouchSprint = useCallback((sprint: boolean) => {
    if (engineRef.current) engineRef.current.keys.sprint = sprint;
  }, []);

  const handleTouchLookDrag = useCallback((dx: number, dy: number) => {
    if (!engineRef.current) return;
    const sensitivity = 0.005;
    engineRef.current.yaw -= dx * sensitivity;
    engineRef.current.pitch -= dy * sensitivity;
    engineRef.current.pitch = Math.max(-Math.PI * 0.42, Math.min(Math.PI * 0.42, engineRef.current.pitch));
  }, []);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black select-none font-sans">
      {/* Isolated Three.js WebGL Canvas Mount Container */}
      <div
        ref={mountRef}
        className="absolute inset-0 z-0 cursor-crosshair"
        onClick={() => {
          if (gameState === 'PLAYING' || gameState === 'PARACHUTING') {
            engineRef.current?.requestPointerLock();
          }
        }}
      />

      {/* Title Screen Overlay */}
      {gameState === 'TITLE' && (
        <TitleScreen
          onStart={handleStartGame}
          isArabic={isArabic}
          onToggleLang={handleToggleLang}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* Active Battle In-Game HUD */}
      {(gameState === 'PLAYING' || gameState === 'PARACHUTING' || gameState === 'PAUSED') && (
        <>
          <GameHUD
            health={health}
            maxHealth={maxHealth}
            armor={armor}
            maxArmor={maxArmor}
            aliveCount={aliveCount}
            kills={kills}
            currentWeapon={currentWeapon}
            currentAmmo={currentAmmo}
            reserveAmmo={reserveAmmo}
            isReloading={isReloading}
            glooCount={glooCount}
            medkitCount={medkitCount}
            altitude={altitude}
            speed={speed}
            isParachuting={isParachuting}
            safeZone={safeZone}
            killFeed={killFeed}
            hitMarkerActive={hitMarkerActive}
            isHeadshotHit={isHeadshotHit}
            playerPos={playerPos}
            playerYaw={playerYaw}
            enemies={enemies}
            isArabic={isArabic}
            onSwitchWeapon={handleSwitchWeapon}
            onDeployGloo={handleDeployGloo}
            onUseMedkit={handleUseMedkit}
            onReload={handleReload}
          />

          {/* Touch Screen Mobile Controls */}
          {isTouchDevice && (
            <TouchControls
              onMove={handleTouchMove}
              onShootStart={handleTouchShootStart}
              onShootEnd={handleTouchShootEnd}
              onJump={handleTouchJump}
              onSprint={handleTouchSprint}
              onReload={handleReload}
              onGlooWall={handleDeployGloo}
              onMedkit={handleUseMedkit}
              onLookDrag={handleTouchLookDrag}
              glooCount={glooCount}
              medkitCount={medkitCount}
              isParachuting={isParachuting}
              isArabic={isArabic}
            />
          )}

          {/* Pause Modal */}
          {gameState === 'PAUSED' && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-none pointer-events-auto">
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-700 text-center max-w-sm">
                <h3 className="text-2xl font-black text-amber-400 mb-2">
                  {isArabic ? 'اللعبة متوقفة مؤقتاً' : 'GAME PAUSED'}
                </h3>
                <p className="text-sm text-slate-300 mb-4">
                  {isArabic ? 'اضغط ESC أو الزر أدناه للمتابعة' : 'Press ESC or resume to continue'}
                </p>
                <button
                  onClick={() => {
                    setGameState(isParachuting ? 'PARACHUTING' : 'PLAYING');
                    engineRef.current?.requestPointerLock();
                  }}
                  className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold cursor-pointer"
                >
                  {isArabic ? 'متابعة المعركة' : 'RESUME'}
                </button>
              </div>
            </div>
          )}
        </>
      )}

      {/* Match Over / Victory BOOYAH! Modal */}
      {matchResult && (
        <GameOverModal
          victory={matchResult.victory}
          stats={matchResult.stats}
          onRestart={handleRestart}
          isArabic={isArabic}
        />
      )}
    </div>
  );
}
